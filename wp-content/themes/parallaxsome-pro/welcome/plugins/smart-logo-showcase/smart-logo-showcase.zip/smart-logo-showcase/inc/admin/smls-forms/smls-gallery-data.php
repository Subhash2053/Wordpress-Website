<?php
defined('ABSPATH') or die("No script kiddies please!");
$gallery_url = $_POST['image_url'];
$logo_type = $_POST['logo_type'];
$gallery_key = $this->smls_generate_random_string(10);
if ($logo_type == 'with_filter') {
    $smls_gallery_prefix = "smls_option[logo][filter_detail][" . sanitize_text_field($_POST['active_filter_key']) . "][filter_logo][" . sanitize_text_field($_POST['logo_key']) . "][gallery_detail][gallery_$gallery_key]";
} else {
    $smls_gallery_prefix = "smls_option[logo][" . sanitize_text_field($_POST['logo_key']) . "][gallery_detail][gallery_$gallery_key]";
}
?>
<div class="smls-gallery-wrap">
    <div class="smls-gallery-image-preview">
        <div class="smls-each-gallery-actions-wrap clearfix">
            <a href="javascript:void(0)" class="smls-move-gallery-image"><span class="dashicons dashicons-move"></span></a>
            <a href="javascript:void(0)" class="smls-delete-gallery-image"><span class="dashicons dashicons-trash"></span></a>
        </div>
        <div class="smls-gallery-collection-wrap">
            <img  class="smls-gallery-image" src="<?php echo esc_attr($gallery_url); ?>" alt="">
        </div>
        <input type="hidden" class="smls-gallery-image-url" name="<?php echo esc_attr($smls_gallery_prefix . '[logo_gallery_url]'); ?>"  value="<?php echo esc_attr($gallery_url); ?>" />
    </div>
</div>
