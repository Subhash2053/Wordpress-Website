<?php
defined('ABSPATH') or die("No script kiddies please!");
global $post;
$post_id = $post->ID;
$smls_settings = get_post_meta($post_id, 'smls_settings', true);
//$this->print_array($smls_settings);
?>
<div class="smls-general-setting-wrapper">
    <div class="smls-setting-wrapper">
        <label><?php _e('Wrapper Width', SMLS_TD); ?></label>
        <div class="smls-setting-field">
            <input type="number" class="smls-wrapper-width" name="smls_settings[main_wrapper_width]" max="100" value="<?php
            if (!empty($smls_settings['main_wrapper_width'])) {
                echo esc_attr($smls_settings['main_wrapper_width']);
            } else {
                echo "100";
            }
            ?>"/>
            <p class="description">
                <?php _e('You can manage the main container or wrapper width of logo.', SMLS_TD); ?>
            </p>
            <p class="description">
                <?php _e('Note: If the logo images get cropped then decreased the wrapper width.', SMLS_TD); ?>
            </p>
        </div>
    </div>
    <div class="smls-extra-effects-wrap">
        <div class="smls-setting-wrapper">
            <label><?php _e('Title Settings', SMLS_TD); ?></label>
            <div class="smls-setting-field">
                <select name="smls_settings[logo_title_view]" class="smls-view-title-type">
                    <option value="title_overlay" <?php if (!empty($smls_settings['logo_title_view'])) selected($smls_settings['logo_title_view'], 'title_overlay'); ?>><?php _e('Show title in overlay', SMLS_TD) ?></option>
                    <option value="title_tooltip" <?php if (!empty($smls_settings['logo_title_view'])) selected($smls_settings['logo_title_view'], 'title_tooltip'); ?>><?php _e('Show title in tooltip', SMLS_TD) ?></option>
                    <option value="title_none" <?php if (!empty($smls_settings['logo_title_view'])) selected($smls_settings['logo_title_view'], 'title_none'); ?>><?php _e('Does not show title', SMLS_TD) ?></option>
                </select>
                <div class="smls-overlay-note"  <?php if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-9') { ?> style="display:none;" <?php } else { ?> style="display:block;" <?php } ?>>
                    <p class="description">
                        <?php _e("If you have selected 'show title in overlay' , please select 'overlay effect' in below image effects options", SMLS_TD); ?>
                    </p>
                    <p class="description">
                        <?php _e("Please note 'Show title in tooltip' is not applicable for flipster layout.", SMLS_TD); ?>
                    </p>
                </div>
                <div class="smls-grid-9-note"  <?php if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-9') { ?> style="display:block;" <?php } else { ?> style="display:none;" <?php } ?>>
                    <p class="description">
                        <?php _e("Please note show title in overlay is not applicable for grid template 9", SMLS_TD); ?>
                    </p>
                </div>
                <div class="smls-carousel-5-note"  <?php if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-9') { ?> style="display:block;" <?php } else { ?> style="display:none;" <?php } ?>>
                    <p class="description">
                        <?php _e("Please note show title in overlay is not applicable for carousel template 5 or 7", SMLS_TD); ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- hover effect
        -->
        <div class="smls-hover-outer-wrap">
            <div class="smls-setting-wrapper">
                <label><?php _e('Image Effects', SMLS_TD); ?></label>
                <div class="smls-setting-field">
                    <select name="smls_settings[logo_image_effects]" class="smls-image-effect-type">
                        <option value="overlay" <?php if (!empty($smls_settings['logo_image_effects'])) selected($smls_settings['logo_image_effects'], 'overlay'); ?>><?php _e('Overlay effect', SMLS_TD) ?></option>
                        <option value="hover" <?php if (!empty($smls_settings['logo_image_effects'])) selected($smls_settings['logo_image_effects'], 'hover'); ?>><?php _e('Hover effect', SMLS_TD) ?></option>
                    </select>
                    <p class="description">
                        <?php _e("To show full view and external link together please select overlay effect", SMLS_TD); ?>
                    </p>
                    <div class="smls-grid-9-note"  <?php if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-9') { ?> style="display:block;" <?php } else { ?> style="display:none;" <?php } ?>>
                        <p class="description">
                            <?php _e("Please note overlay effect is not applicable for grid template 9", SMLS_TD); ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="smls-hover-setting-wrap" <?php if (!isset($smls_settings['smls_show_hover']) || $smls_settings['smls_show_hover'] == 0) { ?>style="display: none;" <?php } else { ?> style="display: block;" <?php } ?>>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Hover Type', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[hover_type]" class="smls-hover-type">
                            <option value="type-1" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-1'); ?>><?php _e('Grey Scale Effect 1', SMLS_TD) ?></option>
                            <option value="type-2" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-2'); ?>><?php _e('Color Effect', SMLS_TD) ?></option>
                            <option value="type-3" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-3'); ?>><?php _e('Zoom In Effect', SMLS_TD) ?></option>
                            <option value="type-4" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-4'); ?>><?php _e('360 Rotate Effect', SMLS_TD) ?></option>
                            <option value="type-5" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-5'); ?>><?php _e('Shine Effect', SMLS_TD) ?></option>
                            <option value="type-6" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-6'); ?>><?php _e('Blur Effect', SMLS_TD) ?></option>
                            <option value="type-7" <?php if (!empty($smls_settings['hover_type'])) selected($smls_settings['hover_type'], 'type-7'); ?>><?php _e('Grey Scale Effect 2', SMLS_TD) ?></option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="smls-without-filter-setting-wrap">
        <div class="smls-setting-wrapper">
            <label><?php _e('Layout', SMLS_TD); ?></label>
            <div class="smls-setting-field">
                <select name="smls_settings[logo_layout]" class="smls-layout-type">
                    <option value="select" <?php if (!empty($smls_settings['logo_layout'])) selected($smls_settings['logo_layout'], 'select'); ?>><?php _e('Select', SMLS_TD) ?></option>
                    <option value="grid" <?php if (!empty($smls_settings['logo_layout'])) selected($smls_settings['logo_layout'], 'grid'); ?>><?php _e('Grid', SMLS_TD) ?></option>
                    <option value="list" <?php if (!empty($smls_settings['logo_layout'])) selected($smls_settings['logo_layout'], 'list'); ?>><?php _e('List', SMLS_TD) ?></option>
                    <option value="carousel" <?php if (!empty($smls_settings['logo_layout'])) selected($smls_settings['logo_layout'], 'carousel'); ?>><?php _e('Carousel', SMLS_TD) ?></option>
                    <option value="perspective" <?php if (!empty($smls_settings['logo_layout'])) selected($smls_settings['logo_layout'], 'perspective'); ?>><?php _e('Flipster', SMLS_TD) ?></option>
                </select>
            </div>
        </div>

        <!--Grid setting section-->
        <div class="smls-grid-setting-wrap">
            <div class="smls-grid-toogle-outer-wrap">
                <h3>
                    <?php _e('Grid Settings', SMLS_TD); ?>
                </h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-inner-toogle-grid" style="display: none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('Grid templates', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[grid_layout]" class="smls-grid-template">
                            <?php for ($k = 1; $k <= 9; $k++) { ?>
                                <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['grid_layout'])) selected($smls_settings['grid_layout'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                            <?php } ?>
                        </select>
                        <div class="smls-grid-demo smls-preview-image">
                            <?php
                            for ($cnt = 1; $cnt <= 9; $cnt++) {
                                if (isset($smls_settings['grid_layout'])) {
                                    $option_value = $smls_settings['grid_layout'];
                                    $exploed_array = explode('-', $option_value);
                                    $cnt_num = $exploed_array[1];
                                    if ($cnt != $cnt_num) {
                                        $style = "style='display:none;'";
                                    } else {
                                        $style = '';
                                    }
                                }
                                ?>
                                <div class="smls-grid-common" id="smls-grid-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo $style; ?>>
                                    <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                    <img src="<?php echo SMLS_IMG_DIR . '/demo/grid-preview/grid-' . $cnt . '.jpg' ?>"/>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="smls-note-grid-7" style="display:none;">
                            <p class="description">
                                <?php _e('Note: Images size must be equal or greater than to width 240px and height 360px for grid template 7.', SMLS_TD); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="smls-grid-border-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Border Color', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="text" class="smls-color-picker" name="smls_settings[grid_border_color]"  value="<?php
                            if (!empty($smls_settings['grid_border_color'])) {
                                echo esc_attr($smls_settings['grid_border_color']);
                            } else {
                                echo "#e9e9e9";
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-grid-bg-wrap" style="display:none;">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Background Color', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="text" class="smls-color-picker" name="smls_settings[grid_background_color]"  value="<?php
                            if (!empty($smls_settings['grid_background_color'])) {
                                echo esc_attr($smls_settings['grid_background_color']);
                            } else {
                                echo "#ffffff";
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-grid-content-container" style="display:none;">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Title Font Size', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="number" class="smls-grid-title-font-size" name="smls_settings[grid_title_font_size]"  value="<?php
                            if (!empty($smls_settings['grid_title_font_size'])) {
                                echo esc_attr($smls_settings['grid_title_font_size']);
                            } else {
                                echo "22";
                            }
                            ?>"/>
                        </div>
                    </div>
                    <div class="smls-grid-color-wrap">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Title Font Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-grid-title-color smls-color-picker" name="smls_settings[grid_title_color]"  value="<?php
                                if (!empty($smls_settings['grid_title_color'])) {
                                    echo esc_attr($smls_settings['grid_title_color']);
                                } else {
                                    echo "#555555";
                                }
                                ?>"/>
                            </div>
                        </div>
                    </div>
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Description Font Size', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="number" class="smls-grid-desc-font-size" name="smls_settings[grid_desc_font_size]"  value="<?php
                            if (!empty($smls_settings['grid_desc_font_size'])) {
                                echo esc_attr($smls_settings['grid_desc_font_size']);
                            } else {
                                echo "14";
                            }
                            ?>"/>
                        </div>
                    </div>
                    <div class="smls-grid-color-wrap">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Description Font Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-grid-desc-color smls-color-picker" name="smls_settings[grid_desc_color]"  value="<?php
                                if (!empty($smls_settings['grid_desc_color'])) {
                                    echo esc_attr($smls_settings['grid_desc_color']);
                                } else {
                                    echo "#333333";
                                }
                                ?>"/>
                            </div>
                        </div>
                    </div>
                    <div class="smls-grid-8bg-color-wrap" style="display:none;">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('First Background Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-grid-firstbg-color smls-color-picker" name="smls_settings[grid_firstbg_color]"  value="<?php
                                if (!empty($smls_settings['grid_firstbg_color'])) {
                                    echo esc_attr($smls_settings['grid_firstbg_color']);
                                } else {
                                    echo "#107dda";
                                }
                                ?>"/>
                            </div>
                        </div>
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Second Background Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-grid-secbg-color smls-color-picker" name="smls_settings[grid_secondbg_color]"  value="<?php
                                if (!empty($smls_settings['grid_secondbg_color'])) {
                                    echo esc_attr($smls_settings['grid_secondbg_color']);
                                } else {
                                    echo "#4ea7f2";
                                }
                                ?>"/>
                            </div>
                        </div>
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Third Background Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-grid-thirdbg-color smls-color-picker" name="smls_settings[grid_thirdbg_color]"  value="<?php
                                if (!empty($smls_settings['grid_thirdbg_color'])) {
                                    echo esc_attr($smls_settings['grid_thirdbg_color']);
                                } else {
                                    echo "#74baf5";
                                }
                                ?>"/>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Column In Desktop', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[desktop_column]" class="smls-column-desktop">
                            <?php for ($k = 6; $k >= 2; $k--) { ?>
                                <option value="<?php echo $k; ?>" <?php if (!empty($smls_settings['desktop_column'])) selected($smls_settings['desktop_column'], $k); ?>><?php echo $k; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Column In Tablet', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[tablet_column]" class="smls-column-tablet">
                            <?php for ($k = 2; $k <= 4; $k++) { ?>
                                <option value="<?php echo $k; ?>" <?php if (!empty($smls_settings['tablet_column'])) selected($smls_settings['tablet_column'], $k); ?>><?php echo $k; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Column In Mobile', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[mobile_column]" class="smls-column-mobile">
                            <?php for ($k = 1; $k <= 2; $k++) { ?>
                                <option value="<?php echo $k; ?>" <?php if (!empty($smls_settings['mobile_column'])) selected($smls_settings['mobile_column'], $k); ?>><?php echo $k; ?></option>

                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <!---End of grid  setting wrap-->
        <div class="smls-carousel-setting-section">
            <div class="smls-carousel-outer-wrap">
                <h3><?php _e('Carousel Settings', SMLS_TD); ?></h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-carousel-inner-wrap" style="display:none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('Carousel Type', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[carousel_type]" class="smls-carousel-type">
                            <option value="horizontal" <?php if (!empty($smls_settings['carousel_type'])) selected($smls_settings['carousel_type'], 'horizontal'); ?>><?php _e('Horizontal', SMLS_TD) ?></option>
                            <option value="vertical" <?php if (!empty($smls_settings['carousel_type'])) selected($smls_settings['carousel_type'], 'vertical'); ?>><?php _e('Vertical', SMLS_TD) ?></option>
                        </select>
                    </div>
                </div>
                <div class="smls-carousel-horiz-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Carousel templates', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[carousel_layout]" class="smls-carousel-template">
                                <?php for ($k = 1; $k <= 10; $k++) { ?>
                                    <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['carousel_layout'])) selected($smls_settings['carousel_layout'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                                <?php } ?>
                            </select>
                            <div class="smls-carousel-demo smls-preview-image">
                                <?php
                                for ($cnt = 1; $cnt <= 10; $cnt++) {
                                    if (isset($smls_settings['carousel_layout'])) {
                                        $option_value = $smls_settings['carousel_layout'];
                                        $exploed_array = explode('-', $option_value);
                                        $cnt_num = $exploed_array[1];
                                        if ($cnt != $cnt_num) {
                                            $style = "style='display:none;'";
                                        } else {
                                            $style = '';
                                        }
                                    }
                                    ?>
                                    <div class="smls-carousel-common" id="smls-carousel-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                        <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                        <img src="<?php echo SMLS_IMG_DIR . '/demo/carousal-preview/carousel-' . $cnt . '.jpg' ?>"/>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="smls-car-border-color" style="display: none;">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Border Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-car-bor-color smls-color-picker" name="smls_settings[car_border_color]"  value="<?php
                                if (!empty($smls_settings['car_border_color'])) {
                                    echo esc_attr($smls_settings['car_border_color']);
                                } else {
                                    echo "#eee";
                                }
                                ?>"/>
                            </div>
                        </div>
                    </div>
                    <div class="smls-car-content-container" style="display:none;">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Title Font Size', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="number" class="smls-car-title-font-size" name="smls_settings[car_title_font_size]"  value="<?php
                                if (!empty($smls_settings['car_title_font_size'])) {
                                    echo esc_attr($smls_settings['car_title_font_size']);
                                } else {
                                    echo "16";
                                }
                                ?>"/>
                            </div>
                        </div>

                        <div class="smls-setting-wrapper">
                            <label><?php _e('Title Font Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-car-title-color smls-color-picker" name="smls_settings[car_title_color]"  value="<?php
                                if (!empty($smls_settings['car_title_color'])) {
                                    echo esc_attr($smls_settings['car_title_color']);
                                } else {
                                    echo "#333333";
                                }
                                ?>"/>
                            </div>
                        </div>
                        <div class="smls-car-desc-wrap" style="display:none;">
                            <div class="smls-setting-wrapper">
                                <label><?php _e('Description Font Size', SMLS_TD); ?></label>
                                <div class="smls-setting-field">
                                    <input type="number" class="smls-car-desc-font-size" name="smls_settings[car_desc_font_size]"  value="<?php
                                    if (!empty($smls_settings['car_desc_font_size'])) {
                                        echo esc_attr($smls_settings['car_desc_font_size']);
                                    } else {
                                        echo "14";
                                    }
                                    ?>"/>
                                </div>
                            </div>

                            <div class="smls-setting-wrapper">
                                <label><?php _e('Description Font Color', SMLS_TD); ?></label>
                                <div class="smls-setting-field">
                                    <input type="text" class="smls-car-desc-color smls-color-picker" name="smls_settings[car_desc_color]"  value="<?php
                                    if (!empty($smls_settings['car_desc_color'])) {
                                        echo esc_attr($smls_settings['car_desc_color']);
                                    } else {
                                        echo "#2e2d2d";
                                    }
                                    ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="smls-pager-setting-wrapper">
            <div class="smls-pager-outer-wrap">
                <h3><?php _e('Pager Settings', SMLS_TD); ?></h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-pager-inner-wrap" style="display:none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('Pager', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[carousel_pager]" class="smls-carousel-pager">
                            <option value="true" <?php if (!empty($smls_settings['carousel_pager'])) selected($smls_settings['carousel_pager'], 'true'); ?>><?php _e('True', SMLS_TD) ?>
                            </option>
                            <option value="false" <?php if (!empty($smls_settings['carousel_pager'])) selected($smls_settings['carousel_pager'], 'false'); ?>><?php _e('False', SMLS_TD) ?>
                            </option>
                        </select>
                    </div>

                </div>
                <div class="smls-pager-hide-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Pager templates', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[pager_template]" class="smls-pager-template">
                                <?php for ($k = 1; $k <= 3; $k++) { ?>
                                    <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['pager_template'])) selected($smls_settings['pager_template'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                                <?php } ?>
                            </select>
                            <div class="smls-pager-demo smls-preview-image">
                                <?php
                                for ($cnt = 1; $cnt <= 3; $cnt++) {
                                    if (isset($smls_settings['pager_template'])) {
                                        $option_value = $smls_settings['pager_template'];
                                        $exploed_array = explode('-', $option_value);
                                        $cnt_num = $exploed_array[1];
                                        if ($cnt != $cnt_num) {
                                            $style = "style='display:none;'";
                                        } else {
                                            $style = '';
                                        }
                                    }
                                    ?>
                                    <div class="smls-pager-common" id="smls-pager-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                        <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                        <img src="<?php echo SMLS_IMG_DIR . '/demo/arrow-pager-preview/pager-' . $cnt . '.jpg' ?>"/>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Active Color', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="text" class="smls-pager-active-color smls-color-picker" name="smls_settings[pager_active_color]"  value="<?php
                            if (!empty($smls_settings['pager_active_color'])) {
                                echo esc_attr($smls_settings['pager_active_color']);
                            } else {
                                echo "#75be08";
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-pager-color-wrap" style="display: none;">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Pager Color', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="text" class="smls-pager-color smls-color-picker" name="smls_settings[pager_color]"  value="<?php
                            if (!empty($smls_settings['pager_color'])) {
                                echo esc_attr($smls_settings['pager_color']);
                            } else {
                                echo "#7c7c7c";
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="smls-slider-setting-wrap">
            <div class="smls-slider-outer-wrap">
                <h3><?php _e('Slider Options Settings', SMLS_TD); ?></h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-slider-inner-wrap" style="display:none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('AutoPlay', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[carousel_auto]" class="smls-carousel-auto">

                            <option value="true" <?php if (!empty($smls_settings['carousel_auto'])) selected($smls_settings['carousel_auto'], 'true'); ?>><?php _e('True', SMLS_TD) ?>
                            </option>
                            <option value="false" <?php if (!empty($smls_settings['carousel_auto'])) selected($smls_settings['carousel_auto'], 'false'); ?>><?php _e('False', SMLS_TD) ?>
                            </option>
                        </select>
                    </div>
                </div>
                <div class="smls-count-slide-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Count Of Slide', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="number" class="smls-carousel-max-slide" name="smls_settings[smls_slide_count]" min="1" max="9" value="<?php
                            if (!empty($smls_settings['smls_slide_count'])) {
                                echo esc_attr($smls_settings['smls_slide_count']);
                            } else {
                                echo 3;
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Auto Play Timeout', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number" class="smls-auto-speed" name="smls_settings[smls_auto_speed]" min="0" value="<?php
                        if (!empty($smls_settings['smls_auto_speed'])) {
                            echo esc_attr($smls_settings['smls_auto_speed']);
                        } else {
                            echo 2000;
                        }
                        ?>"/>
                    </div>
                </div>
           
                <div class="smls-setting-wrapper">
                    <label><?php _e('Controls', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[carousel_controls]" class="smls-carousel-controls">

                            <option value="true" <?php if (!empty($smls_settings['carousel_controls'])) selected($smls_settings['carousel_controls'], 'true'); ?>><?php _e('True', SMLS_TD) ?>
                            </option>
                            <option value="false" <?php if (!empty($smls_settings['carousel_controls'])) selected($smls_settings['carousel_controls'], 'false'); ?>><?php _e('False', SMLS_TD) ?>
                            </option>
                        </select>
                    </div>
                </div>
                <div class="smls-car-control-type-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Controls Type', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[controls_type]" class="smls-controls-type">

                                <option value="arrow" <?php if (!empty($smls_settings['controls_type'])) selected($smls_settings['controls_type'], 'arrow'); ?>><?php _e('Arrow', SMLS_TD) ?>
                                </option>
                                <option value="text" <?php if (!empty($smls_settings['controls_type'])) selected($smls_settings['controls_type'], 'text'); ?>><?php _e('Text', SMLS_TD) ?>
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="smls-controls-true-wrap">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Arrow Types', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <select name="smls_settings[arrow_type]" class="smls-arrow-type">
                                    <?php for ($k = 1; $k <= 5; $k++) { ?>
                                        <option value="type-<?php echo $k; ?>" <?php if (!empty($smls_settings['arrow_type'])) selected($smls_settings['arrow_type'], 'type-' . $k); ?>><?php _e('Type ', SMLS_TD) ?><?php echo $k; ?></option>
                                    <?php } ?>
                                </select>
                                <div class="smls-arrow-demo smls-preview-image">
                                    <?php
                                    for ($cnt = 1; $cnt <= 5; $cnt++) {
                                        if (isset($smls_settings['arrow_type'])) {
                                            $option_value = $smls_settings['arrow_type'];
                                            $exploed_array = explode('-', $option_value);
                                            $cnt_num = $exploed_array[1];
                                            if ($cnt != $cnt_num) {
                                                $style = "style='display:none;'";
                                            } else {
                                                $style = '';
                                            }
                                        }
                                        ?>
                                        <div class="smls-arrow-common" id="smls-arrow-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                            <h4><?php _e('Type', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                            <img src="<?php echo SMLS_IMG_DIR . '/demo/arrow-pager-preview/arrow-' . $cnt . '.jpg' ?>"/>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Arrow Color', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <input type="text" class="smls-arrow-color smls-color-picker" name="smls_settings[arrow_color]"  value="<?php
                                if (!empty($smls_settings['arrow_color'])) {
                                    echo esc_attr($smls_settings['arrow_color']);
                                } else {
                                    echo "#474747";
                                }
                                ?>"/>
                            </div>
                        </div>
                        <div class="smls-arrow-hover-wrap">
                            <div class="smls-setting-wrapper">
                                <label><?php _e('Arrow Hover Color', SMLS_TD); ?></label>
                                <div class="smls-setting-field">
                                    <input type="text" class="smls-arrow-hover-color smls-color-picker" name="smls_settings[arrow_hover_color]"  value="<?php
                                    if (!empty($smls_settings['arrow_hover_color'])) {
                                        echo esc_attr($smls_settings['arrow_hover_color']);
                                    } else {
                                        echo "rgba(71, 71, 71, 0.7)";
                                    }
                                    ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Carousel setting configuration-->
        <div class="smls-list-setting-wrap">
            <div class="smls-list-setting-outer-wrap">
                <h3><?php _e('List Settings', SMLS_TD); ?></h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-list-setting-inner-wrap" style="display: none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('List Templates', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[list_layout]" class="smls-list-template">
                            <?php for ($k = 1; $k <= 2; $k++) { ?>
                                <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['list_layout'])) selected($smls_settings['list_layout'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>
                            <?php } ?>
                        </select>
                        <div class="smls-list-demo smls-preview-image">
                            <?php
                            for ($cnt = 1; $cnt <= 2; $cnt++) {
                                if (isset($smls_settings['list_layout'])) {
                                    $option_value = $smls_settings['list_layout'];
                                    $exploed_array = explode('-', $option_value);
                                    $cnt_num = $exploed_array[1];
                                    if ($cnt != $cnt_num) {
                                        $style = "style='display:none;'";
                                    } else {
                                        $style = '';
                                    }
                                }
                                ?>
                                <div class="smls-list-common" id="smls-list-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                    <h4><?php _e('Type', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                    <img src="<?php echo SMLS_IMG_DIR . '/demo/list-preview/list-' . $cnt . '.jpg' ?>"/>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Title Font Size', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number" class="smls-list-title-font-size" name="smls_settings[list_title_font_size]"  value="<?php
                        if (!empty($smls_settings['list_title_font_size'])) {
                            echo esc_attr($smls_settings['list_title_font_size']);
                        } else {
                            echo "18";
                        }
                        ?>"/>
                    </div>
                </div>

                <div class="smls-setting-wrapper">
                    <label><?php _e('Title Font Color', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="text" class="smls-list-title-color smls-color-picker" name="smls_settings[list_title_color]"  value="<?php
                        if (!empty($smls_settings['list_title_color'])) {
                            echo esc_attr($smls_settings['list_title_color']);
                        } else {
                            echo "#000000";
                        }
                        ?>"/>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Description Font Size', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number" class="smls-list-desc-font-size" name="smls_settings[list_desc_font_size]"  value="<?php
                        if (!empty($smls_settings['list_desc_font_size'])) {
                            echo esc_attr($smls_settings['list_desc_font_size']);
                        } else {
                            echo "14";
                        }
                        ?>"/>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Description Font Color', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="text" class="smls-list-desc-color smls-color-picker" name="smls_settings[list_desc_color]"  value="<?php
                        if (!empty($smls_settings['list_desc_color'])) {
                            echo esc_attr($smls_settings['list_desc_color']);
                        } else {
                            echo "#666666";
                        }
                        ?>"/>
                    </div>
                </div>
            </div>
        </div>
        <div class="smls-perspective-settings-wrap">
            <div class="smls-perspective-outer-setting-wrap">
                <h3><?php _e('Flipster Settings', SMLS_TD); ?></h3>
                <span class="dashicons dashicons-arrow-down"></span>
            </div>
            <div class="smls-perspective-inner-wrap" style="display: none;">
                <div class="smls-setting-wrapper">
                    <label><?php _e('Flipster Templates', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[perspective_layout]" class="smls-perspective-template">
                            <?php for ($k = 1; $k <= 4; $k++) { ?>
                                <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['perspective_layout'])) selected($smls_settings['perspective_layout'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                            <?php } ?>
                        </select>
                        <div class="smls-perspective-demo smls-preview-image">
                            <?php
                            for ($cnt = 1; $cnt <= 4; $cnt++) {
                                if (isset($smls_settings['perspective_layout'])) {
                                    $option_value = $smls_settings['perspective_layout'];
                                    $exploed_array = explode('-', $option_value);
                                    $cnt_num = $exploed_array[1];
                                    if ($cnt != $cnt_num) {
                                        $style = "style='display:none;'";
                                    } else {
                                        $style = '';
                                    }
                                }
                                ?>
                                <div class="smls-perspective-common" id="smls-perspective-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                    <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                    <img src="<?php echo SMLS_IMG_DIR . '/demo/flipster-preview/flipster-' . $cnt . '.jpg' ?>"/>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="smls-perspective-color-wrap" style="display: none;">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Title Background Color', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="text" class="smls-pers-bg-color smls-color-picker" name="smls_settings[perspective_bg_color]"  value="<?php
                            if (!empty($smls_settings['perspective_bg_color'])) {
                                echo esc_attr($smls_settings['perspective_bg_color']);
                            } else {
                                echo "#75bd07";
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="smls-filter-setting-wrap">
        <div class="smls-filter-outer-setting-wrap">
            <h3><?php _e('Filter Settings', SMLS_TD); ?></h3>
            <span class="dashicons dashicons-arrow-down"></span>
        </div>
        <div class="smls-filter-inner-setting-wrap" style="display: none;">
            <div class="smls-setting-wrapper">
                <label><?php _e('Filter Type', SMLS_TD); ?></label>
                <div class="smls-setting-field">
                    <select name="smls_settings[filter_type]" class="smls-filter-type">
                        <option value="normal" <?php if (!empty($smls_settings['filter_type'])) selected($smls_settings['filter_type'], 'normal'); ?>><?php _e('Normal', SMLS_TD) ?></option>
                        <option value="blur" <?php if (!empty($smls_settings['filter_type'])) selected($smls_settings['filter_type'], 'blur'); ?>><?php _e('Blur', SMLS_TD) ?></option>
                    </select>
                </div>
            </div>
            <div class="smls-setting-wrapper">
                <label><?php _e('Filter Tab Templates', SMLS_TD); ?></label>
                <div class="smls-setting-field">
                    <select name="smls_settings[filter_tab_template]" class="smls-filter-tab-template">
                        <?php for ($k = 1; $k <= 6; $k++) { ?>
                            <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['filter_tab_template'])) selected($smls_settings['filter_tab_template'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                        <?php } ?>
                    </select>
                    <div class="smls-filter-tab-demo smls-preview-image">
                        <?php
                        for ($cnt = 1; $cnt <= 6; $cnt++) {
                            if (isset($smls_settings['filter_tab_template'])) {
                                $option_value = $smls_settings['filter_tab_template'];
                                $exploed_array = explode('-', $option_value);
                                $cnt_num = $exploed_array[1];
                                if ($cnt != $cnt_num) {
                                    $style = "style='display:none;'";
                                } else {
                                    $style = '';
                                }
                            }
                            ?>
                            <div class="smls-filter-tab-common" id="smls-filter-tab-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo esc_attr($style); ?>>
                                <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                <img src="<?php echo SMLS_IMG_DIR . '/demo/filter-preview/filter-tabs/filter-tabs-' . $cnt . '.jpg' ?>"/>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <!--Filter animation settings-->
            <div class="smls-normal-filter-wrap">
                <div class="smls-setting-wrapper">
                    <label><?php _e('Filter Layout', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[filter_layout]" class="smls-filter-layout">
                            <option value="sameSize" <?php if (!empty($smls_settings['filter_layout'])) selected($smls_settings['filter_layout'], 'sameSize'); ?>><?php _e('Same Size', SMLS_TD) ?></option>
                            <option value="packed" <?php if (!empty($smls_settings['filter_layout'])) selected($smls_settings['filter_layout'], 'packed'); ?>><?php _e('Packed', SMLS_TD) ?></option>
                            <option value="sameHeight" <?php if (!empty($smls_settings['filter_layout'])) selected($smls_settings['filter_layout'], 'sameHeight'); ?>><?php _e('Same Height', SMLS_TD) ?></option>
                            <option value="sameWidth" <?php if (!empty($smls_settings['filter_layout'])) selected($smls_settings['filter_layout'], 'sameWidth'); ?>><?php _e('Same Width', SMLS_TD) ?></option>
                        </select>
                    </div>
                </div>
                <div class="smls-filter-template-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Filter Templates', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[filter_same_size_template]" class="smls-filter-template">
                                <?php for ($k = 1; $k <= 2; $k++) { ?>
                                    <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['filter_same_size_template'])) selected($smls_settings['filter_same_size_template'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>
                                <?php } ?>
                            </select>
                            <div class="smls-filter-template-demo smls-preview-image">
                                <?php
                                for ($cnt = 1; $cnt <= 2; $cnt++) {
                                    if (isset($smls_settings['filter_same_size_template'])) {
                                        $option_value = $smls_settings['filter_same_size_template'];
                                        $exploed_array = explode('-', $option_value);
                                        $cnt_num = $exploed_array[1];
                                        if ($cnt != $cnt_num) {
                                            $style = "style='display:none;'";
                                        } else {
                                            $style = '';
                                        }
                                    }
                                    ?>
                                    <div class="smls-filter-template-common" id="smls-filter-template-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo $style; ?>>
                                        <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                        <img src="<?php echo SMLS_IMG_DIR . '/demo/filter-preview/filter-same-size-' . $cnt . '.jpg' ?>"/>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="smls-filter-logo-width-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Logo Width', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="number" class="smls-same-width" name="smls_settings[smls_same_width]" value="<?php
                            if (!empty($smls_settings['smls_same_width'])) {
                                echo esc_attr($smls_settings['smls_same_width']);
                            } else {
                                echo 200;
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-filter-logo-height-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Logo Height', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <input type="number" class="smls-same-height" name="smls_settings[smls_same_height]"  value="<?php
                            if (!empty($smls_settings['smls_same_height'])) {
                                echo esc_attr($smls_settings['smls_same_height']);
                            } else {
                                echo 200;
                            }
                            ?>"/>
                        </div>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Delay Mode', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[delay_mode]" class="smls-filter-mode">
                            <option value="progressive" <?php if (!empty($smls_settings['delay_mode'])) selected($smls_settings['delay_mode'], 'progressive'); ?>><?php _e('Progressive', SMLS_TD) ?></option>
                            <option value="alternate" <?php if (!empty($smls_settings['delay_mode'])) selected($smls_settings['delay_mode'], 'alternate'); ?>><?php _e('Alternate', SMLS_TD) ?></option>
                        </select>
                        <p class="description">Progressive delay mode increases the transition-delay property of your items consecutively by the amount you've set the Delay option in below field.</p>
                        <p class="description">Alternate  delay mode sets the transition-delay property of every other item to the amount you've set the delay option in below field.</p>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Delay', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number" min="0" name="smls_settings[delay]" class="smls-filter-delay" value="<?php
                        if (isset($smls_settings['delay'])) {
                            echo esc_attr($smls_settings['delay']);
                        } else {
                            echo '0';
                        }
                        ?>" />
                        <p class="description">If you choose Progressive delay mode then please select a value between 25-50 ms for an optimal effect.</p>
                        <p class="description">If you choose Alternate delay mode then please select a value between  250-400 ms for an optimal effect.
                        </p>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Animation Duration', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number"  name="smls_settings[animation_duration]" class="smls-filter-animation-duration" value="<?php
                        if (isset($smls_settings['animation_duration'])) {
                            echo esc_attr($smls_settings['animation_duration']);
                        } else {
                            echo '0.6';
                        }
                        ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="smls-tooltip-main-wrapper">
        <div class="smls-tooltip-outer-wrap">
            <h3><?php _e('Tooltip Settings', SMLS_TD) ?></h3>
            <span class="dashicons dashicons-arrow-down"></span>
        </div>
        <div class="smls-tooltip-inner-wrap" style="display: none;">
            <div class="smls-tooltip-collection-warp" <?php if (isset($smls_settings['smls_show_tooltip']) && $smls_settings['smls_show_tooltip'] == 0) { ?>style="display: none;" <?php } else { ?> style="display: block;" <?php } ?>>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Tooltip Templates', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[tooltip_template]" class="smls-tooltip-template">
                            <?php for ($k = 1; $k <= 5; $k++) { ?>
                                <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['tooltip_template'])) selected($smls_settings['tooltip_template'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>
                            <?php } ?>
                        </select>
                        <div class="smls-tooltip-demo smls-preview-image">
                            <?php
                            for ($cnt = 1; $cnt <= 5; $cnt++) {
                                if (isset($smls_settings['tooltip_template'])) {
                                    $option_value = $smls_settings['tooltip_template'];
                                    $exploed_array = explode('-', $option_value);
                                    $cnt_num = $exploed_array[1];
                                    if ($cnt != $cnt_num) {
                                        $style = "style='display:none;'";
                                    } else {
                                        $style = '';
                                    }
                                }
                                ?>
                                <div class="smls-tooltip-common" id="smls-tooltip-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo $style; ?>>
                                    <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                    <img src="<?php echo SMLS_IMG_DIR . '/demo/tooltip/tooltip-' . $cnt . '.jpg' ?>"/>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Tooltip Position', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[tooltip_position]" class="smls-tooltip-position">
                            <option value="top" <?php if (!empty($smls_settings['tooltip_position'])) selected($smls_settings['tooltip_position'], 'top'); ?>><?php _e('Top', SMLS_TD) ?></option>
                            <option value="bottom" <?php if (!empty($smls_settings['tooltip_position'])) selected($smls_settings['tooltip_position'], 'bottom'); ?>><?php _e('Bottom', SMLS_TD) ?></option>
                            <option value="right" <?php if (!empty($smls_settings['tooltip_position'])) selected($smls_settings['tooltip_position'], 'right'); ?>><?php _e('Right', SMLS_TD) ?></option>
                            <option value="left" <?php if (!empty($smls_settings['tooltip_position'])) selected($smls_settings['tooltip_position'], 'left'); ?>><?php _e('Left', SMLS_TD) ?></option>
                        </select>
                        <p class="description">
                            <?php _e('Determines tooltip position.', SMLS_TD) ?>
                        </p>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Animation', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <select name="smls_settings[tooltip_animation]" class="smls-tooltip-animation">
                            <option value="fade" <?php if (!empty($smls_settings['tooltip_animation'])) selected($smls_settings['tooltip_animation'], 'fade'); ?>><?php _e('Fade', SMLS_TD) ?></option>
                            <option value="grow" <?php if (!empty($smls_settings['tooltip_animation'])) selected($smls_settings['tooltip_animation'], 'grow'); ?>><?php _e('Grow', SMLS_TD) ?></option>
                            <option value="swing" <?php if (!empty($smls_settings['tooltip_animation'])) selected($smls_settings['tooltip_animation'], 'swing'); ?>><?php _e('Swing', SMLS_TD) ?></option>
                            <option value="slide" <?php if (!empty($smls_settings['tooltip_animation'])) selected($smls_settings['tooltip_animation'], 'slide'); ?>><?php _e('Slide', SMLS_TD) ?></option>
                            <option value="fall" <?php if (!empty($smls_settings['tooltip_animation'])) selected($smls_settings['tooltip_animation'], 'fall'); ?>><?php _e('fall', SMLS_TD) ?></option>
                        </select>
                        <p class="description">
                            <?php _e('Determines how the tooltip will animate in and out.', SMLS_TD) ?>
                        </p>
                    </div>
                </div>
                <div class="smls-setting-wrapper">
                    <label><?php _e('Animation Duration', SMLS_TD); ?></label>
                    <div class="smls-setting-field">
                        <input type="number" class="smls-tooltip-duration" name="smls_settings[tooltip_duration]" value="<?php
                        if (!empty($smls_settings['tooltip_duration'])) {
                            echo esc_attr($smls_settings['tooltip_duration']);
                        } else {
                            echo 350;
                        }
                        ?>"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="smls-full-view-main-wrapper" <?php if (isset($smls_settings['grid_layout']) && ($smls_settings['grid_layout'] == 'template-7' || $smls_settings['grid_layout'] == 'template-8' || $smls_settings['grid_layout'] == 'template-9')) { ?> style="display: none;"  <?php } else { ?>
             style = "display: block;" <?php }
                        ?>>
        <div class="smls-full-view-outer-wrap">
            <h3><?php _e('Full View Settings', SMLS_TD) ?></h3>
            <span class="dashicons dashicons-arrow-down"></span>
        </div>
        <div class="smls-full-view-inner-wrap" style="display:none;">
            <div class="smls-setting-wrapper">
                <label for="smls-full-view-check" class="smls-full-view"><?php _e('Full View', SMLS_TD); ?></label>
                <div class="smls-setting-field">
                    <label class="smls-button-check">
                        <input type="checkbox" class="smls-show-full-view"  <?php if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == '1') { ?>checked="checked"<?php } ?> />
                        <?php _e('Check to show full detail of logo', SMLS_TD) ?></label>
                    <input type="hidden" name="smls_settings[smls_show_full_view]" class="smls-show-full-view-value" value="<?php
                    if (isset($smls_settings['smls_show_full_view'])) {
                        echo esc_attr($smls_settings['smls_show_full_view']);
                    }
                    ?>" />
                </div>
            </div>

            <div class="smls-full-view-setting-wrap" <?php if (!isset($smls_settings['smls_show_full_view']) || $smls_settings['smls_show_full_view'] == 0) { ?>style="display: none;" <?php } else { ?> style="display: block;" <?php } ?>>
                <div class="smls-full-detail-wrap">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Full View Type', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[full_view_type]" class="smls-full-view-type">
                                <option  value="popup" <?php if (!empty($smls_settings['full_view_type'])) selected($smls_settings['full_view_type'], 'popup'); ?>><?php _e('Popup', SMLS_TD) ?></option>
                                <option class="smls-inline-on" value="inline" <?php if (!empty($smls_settings['full_view_type'])) selected($smls_settings['full_view_type'], 'inline'); ?>><?php _e('Inline ', SMLS_TD) ?></option>
                            </select>
                            <div class="smls-note-wrap" style="display:none;">
                                <p class="description">
                                    <?php _e('Please note the inline view is not applicable for current layout or logo type', SMLS_TD); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="smls-inline-setting-wrap">
                        <div class="smls-setting-wrapper">
                            <label><?php _e('Inline Templates', SMLS_TD); ?></label>
                            <div class="smls-setting-field">
                                <select name="smls_settings[inline_layout]" class="smls-inline-template">
                                    <?php for ($k = 1; $k <= 3; $k++) { ?>
                                        <option value="template-<?php echo $k; ?>" <?php if (!empty($smls_settings['inline_layout'])) selected($smls_settings['inline_layout'], 'template-' . $k); ?>><?php _e('Template ', SMLS_TD) ?><?php echo $k; ?></option>

                                    <?php } ?>
                                </select>
                                <div class="smls-inline-demo smls-preview-image">
                                    <?php
                                    for ($cnt = 1; $cnt <= 3; $cnt++) {
                                        if (isset($smls_settings['inline_layout'])) {
                                            $option_value = $smls_settings['inline_layout'];
                                            $exploed_array = explode('-', $option_value);
                                            $cnt_num = $exploed_array[1];
                                            if ($cnt != $cnt_num) {
                                                $style = "style='display:none;'";
                                            } else {
                                                $style = '';
                                            }
                                        }
                                        ?>
                                        <div class="smls-inline-common" id="smls-inline-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo $style; ?>>
                                            <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                            <img src="<?php echo SMLS_IMG_DIR . '/demo/full-view-preview/inline-' . $cnt . '.jpg' ?>"/>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="smls-popup-settings-wrap" style="display: none;">
                    <div class="smls-setting-wrapper">
                        <label><?php _e('Popup Template', SMLS_TD); ?></label>
                        <div class="smls-setting-field">
                            <select name="smls_settings[popup_template]" class="smls-popup-type">
                                <option value="template-1" <?php if (!empty($smls_settings['popup_template'])) selected($smls_settings['popup_template'], 'template-1'); ?>><?php _e('Template 1', SMLS_TD) ?></option>
                                <option value="template-2" <?php if (!empty($smls_settings['popup_template'])) selected($smls_settings['popup_template'], 'template-2'); ?>><?php _e('Template 2', SMLS_TD) ?></option>
                            </select>
                            <div class="smls-popup-demo smls-preview-image">
                                <?php
                                for ($cnt = 1; $cnt <= 2; $cnt++) {
                                    if (isset($smls_settings['popup_template'])) {
                                        $option_value = $smls_settings['popup_template'];
                                        $exploed_array = explode('-', $option_value);
                                        $cnt_num = $exploed_array[1];
                                        if ($cnt != $cnt_num) {
                                            $style = "style='display:none;'";
                                        } else {
                                            $style = '';
                                        }
                                    }
                                    ?>
                                    <div class="smls-popup-common" id="smls-popup-demo-<?php echo $cnt; ?>" <?php if (isset($style)) echo $style; ?>>
                                        <h4><?php _e('Template', SMLS_TD); ?> <?php echo $cnt; ?> <?php _e('Preview', SMLS_TD); ?></h4>
                                        <img src="<?php echo SMLS_IMG_DIR . '/demo/full-view-preview/popup-' . $cnt . '.jpg' ?>"/>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

