<style>
    .smls-main-logo-outer-<?php echo $random_num; ?>.smls-main-logo-wrapper {
        width: <?php echo (isset($smls_settings['main_wrapper_width'])) ? esc_attr($smls_settings['main_wrapper_width']) : '100' ?>%;
        margin:0 auto;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-popup-wrap:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-grid-each-item:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-grid-image-wrap:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-popup-wrap:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-grid-each-item:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-grid-image-wrap:before {

        border-left: 1px solid <?php echo isset($smls_settings['grid_border_color']) ? esc_attr($smls_settings['grid_border_color']) : '#e9e9e9'; ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-popup-wrap:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-grid-each-item:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-1 .smls-grid-image-wrap:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-popup-wrap:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-grid-each-item:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 .smls-grid-image-wrap:after {
        border-bottom: 1px solid <?php
        if (isset($smls_settings['grid_border_color'])) {
            echo esc_attr($smls_settings['grid_border_color']);
        } else {
            echo '#e9e9e9';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-2 {
        border: 1px solid <?php
        if (isset($smls_settings['grid_border_color'])) {
            echo esc_attr($smls_settings['grid_border_color']);
        } else {
            echo '#e9e9e9';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-4 .smls-popup-wrap, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-4 .smls-grid-each-item, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-4 .smls-grid-image-wrap {
        border: 1px solid <?php
        if (isset($smls_settings['grid_border_color'])) {
            echo esc_attr($smls_settings['grid_border_color']);
        } else {
            echo '#e9e9e9';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-5 .smls-popup-wrap, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-5 .smls-grid-each-item, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-5 .smls-grid-image-wrap {
        background-color:  <?php
        if (isset($smls_settings['grid_background_color'])) {
            echo esc_attr($smls_settings['grid_background_color']);
        } else {
            echo '#ffffff';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-7 .smls-hover-title {
        color: <?php
        if (isset($smls_settings['grid_title_color'])) {
            echo esc_attr($smls_settings['grid_title_color']);
        } else {
            echo '#555555';
        }
        ?>;
        font-size: <?php
        if (isset($smls_settings['grid_title_font_size'])) {
            echo esc_attr($smls_settings['grid_title_font_size']);
        } else {
            echo '22';
        }
        ?>px;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-7 .smls-hover-description {
        color: <?php
        if (isset($smls_settings['grid_desc_color'])) {
            echo esc_attr($smls_settings['grid_desc_color']);
        } else {
            echo '#333333';
        }
        ?>;
        font-size: <?php
        if (isset($smls_settings['grid_desc_font_size'])) {
            echo esc_attr($smls_settings['grid_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-title {
        font-size:  <?php
        if (isset($smls_settings['grid_title_font_size'])) {
            echo esc_attr($smls_settings['grid_title_font_size']);
        } else {
            echo '20';
        }
        ?>px;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-grid-eight-toggle-content .smls-grid-desp, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-tagline {
        font-size: <?php
        if (isset($smls_settings['grid_desc_font_size'])) {
            echo esc_attr($smls_settings['grid_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-eight-outer-container {
        background-color:<?php
        if (isset($smls_settings['grid_firstbg_color'])) {
            echo esc_attr($smls_settings['grid_firstbg_color']);
        } else {
            echo '#107dda';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(2n) .smls-eight-outer-container,
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(2n+1) .smls-eight-outer-container {
        background-color:<?php
        if (isset($smls_settings['grid_secondbg_color'])) {
            echo esc_attr($smls_settings['grid_secondbg_color']);
        } else {
            echo '#4ea7f2';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(3n) .smls-eight-outer-container  {
        background-color: <?php
        if (isset($smls_settings['grid_thirdbg_color'])) {
            echo esc_attr($smls_settings['grid_thirdbg_color']);
        } else {
            echo '#74baf5';
        }
        ?>;
    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(3n+1) .smls-eight-outer-container  {
        background-color:<?php
        if (isset($smls_settings['grid_firstbg_color'])) {
            echo esc_attr($smls_settings['grid_firstbg_color']);
        } else {
            echo '#107dda';
        }
        ?>;
    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-block-content-wrap:before {

        border-color:transparent transparent <?php
        if (isset($smls_settings['grid_firstbg_color'])) {
            echo esc_attr($smls_settings['grid_firstbg_color']);
        } else {
            echo '#107dda';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(2n) .smls-block-content-wrap:before,
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(2n+1) .smls-block-content-wrap:before {
        border-color:transparent transparent <?php
        if (isset($smls_settings['grid_secondbg_color'])) {
            echo esc_attr($smls_settings['grid_secondbg_color']);
        } else {
            echo '#4ea7f2';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(3n) .smls-block-content-wrap:before {
        border-color:transparent transparent  <?php
        if (isset($smls_settings['grid_thirdbg_color'])) {
            echo esc_attr($smls_settings['grid_thirdbg_color']);
        } else {
            echo '#74baf5';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-8 .smls-logo-rec-wrap:nth-of-type(3n+1) .smls-block-content-wrap:before {
        border-color:transparent transparent <?php
        if (isset($smls_settings['grid_firstbg_color'])) {
            echo esc_attr($smls_settings['grid_firstbg_color']);
        } else {
            echo '#107dda';
        }
        ?>;
    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-9 .smls-grid-nine-title {
        font-size:  <?php
        if (isset($smls_settings['grid_title_font_size'])) {
            echo esc_attr($smls_settings['grid_title_font_size']);
        } else {
            echo '16';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['grid_title_color'])) {
            echo esc_attr($smls_settings['grid_title_color']);
        } else {
            echo '#f46632';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-9 .smls-social-icons a {
        background-color: <?php
        if (isset($smls_settings['grid_title_color'])) {
            echo esc_attr($smls_settings['grid_title_color']);
        } else {
            echo '#f46632';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-main-logo-outer-<?php echo $random_num; ?> .smls-grid-container-template-9 .smls-grid-desp {
        font-size: <?php
        if (isset($smls_settings['grid_desc_font_size'])) {
            echo esc_attr($smls_settings['grid_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['grid_desc_color'])) {
            echo esc_attr($smls_settings['grid_desc_color']);
        } else {
            echo '#666666';
        }
        ?>;;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-2 .smls-carousel-two-title {
        font-size: <?php
        if (isset($smls_settings['car_title_font_size'])) {
            echo esc_attr($smls_settings['car_title_font_size']);
        } else {
            echo '16';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#333333';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-2 .smls-carousel-two-description {

        font-size: <?php
        if (isset($smls_settings['car_desc_font_size'])) {
            echo esc_attr($smls_settings['car_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color:  <?php
        if (isset($smls_settings['car_desc_color'])) {
            echo esc_attr($smls_settings['car_desc_color']);
        } else {
            echo '#2e2d2d';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-3 .smls-carousel-two-title {

        font-size: <?php
        if (isset($smls_settings['car_title_font_size'])) {
            echo esc_attr($smls_settings['car_title_font_size']);
        } else {
            echo '18';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#f6881f';
        }
        ?>;

    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-3 .smls-social-icon-wrap a {

        background-color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#f6881f';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-5 .smls-carousel-two-title, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-6 .smls-carousel-two-title {

        font-size:  <?php
        if (isset($smls_settings['car_title_font_size'])) {
            echo esc_attr($smls_settings['car_title_font_size']);
        } else {
            echo '18';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#fc562e';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-5 .smls-carousel-two-description, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-6 .smls-carousel-two-description {
        font-size: <?php
        if (isset($smls_settings['car_desc_font_size'])) {
            echo esc_attr($smls_settings['car_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_desc_color'])) {
            echo esc_attr($smls_settings['car_desc_color']);
        } else {
            echo '#7b7b7b';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-5 .smls-social-icon-wrap a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-6 .smls-social-icon-wrap a {

        background-color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#fc562e';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-7 .smls-carousel-two-title {

        font-size:  <?php
        if (isset($smls_settings['car_title_font_size'])) {
            echo esc_attr($smls_settings['car_title_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#ffffff';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-7 .smls-carousel-two-description {

        font-size:  <?php
        if (isset($smls_settings['car_desc_font_size'])) {
            echo esc_attr($smls_settings['car_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['car_desc_color'])) {
            echo esc_attr($smls_settings['car_desc_color']);
        } else {
            echo '#ffffff';
        }
        ?>;

    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-7 .smls-social-icon-wrap a {
        background-color:  <?php
        if (isset($smls_settings['car_title_color'])) {
            echo esc_attr($smls_settings['car_title_color']);
        } else {
            echo '#ffffff';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-1.owl-theme .owl-dots .owl-dot:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-1 .bx-wrapper .bx-pager.bx-default-pager a:before {
        background-color: <?php
        if (isset($smls_settings['pager_active_color'])) {
            echo esc_attr($smls_settings['pager_active_color']);
        } else {
            echo '#75be08';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-2.owl-theme .owl-dots .owl-dot span:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-2 .bx-wrapper .bx-pager.bx-default-pager a:before {

        background-color:  <?php
        if (isset($smls_settings['pager_active_color'])) {
            echo esc_attr($smls_settings['pager_active_color']);
        } else {
            echo '#0d98dc';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-2.owl-theme .owl-dots .owl-dot span, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-2 .bx-wrapper .bx-pager.bx-default-pager a {
        background:  <?php
        if (isset($smls_settings['pager_color'])) {
            echo esc_attr($smls_settings['pager_color']);
        } else {
            echo '#7c7c7c';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-3.owl-theme .owl-dots .owl-dot span:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-3.owl-theme .owl-dots .owl-dot.active span, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-3 .bx-wrapper .bx-pager.bx-default-pager a:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-3 .bx-wrapper .bx-pager.bx-default-pager a.active {
        background-color:  <?php
        if (isset($smls_settings['pager_active_color'])) {
            echo esc_attr($smls_settings['pager_active_color']);
        } else {
            echo '#f7a644';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-pager-template-3.owl-theme .owl-dots .owl-dot span, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-bx-pager-template-3 .bx-wrapper .bx-pager.bx-default-pager a {
        background-color: <?php
        if (isset($smls_settings['pager_color'])) {
            echo esc_attr($smls_settings['pager_color']);
        } else {
            echo '#cacaca';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-1.owl-theme .owl-controls .owl-nav [class*=owl-]:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-1 .bx-controls-direction a:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-1 a.flipto-pre:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-1 a.flipto-next:hover {
        background-color: <?php
        if (isset($smls_settings['arrow_hover_color'])) {
            echo esc_attr($smls_settings['arrow_hover_color']);
        } else {
            echo 'rgba(71, 71, 71, 0.7)';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-1.owl-theme .owl-controls .owl-nav [class*=owl-], .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-1 .bx-controls-direction a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-1 a.flipto-prev, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-1 a.flipto-next {
        background-color: <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#474747';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-2.owl-theme .owl-controls .owl-nav [class*=owl-], .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-2 .bx-controls-direction a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-2 a.flipto-prev, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-2 a.flipto-next {
        background-color:  <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#bcbcbc';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-2.owl-theme .owl-controls .owl-nav [class*=owl-]:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-2 .bx-controls-direction a:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-2 a.flipto-prev:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-2 a.flipto-next:hover {
        background-color: <?php
        if (isset($smls_settings['arrow_hover_color'])) {
            echo esc_attr($smls_settings['arrow_hover_color']);
        } else {
            echo '#f6881f';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-3.owl-theme .owl-controls .owl-nav [class*=owl-], .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-3 .bx-controls-direction a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-prev, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-next {

        border: 2px solid <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#e8e8e8';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-3.owl-theme .owl-controls .owl-nav [class*=owl-]:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-3 .bx-controls-direction a:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-prev:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-next:before {
        background-color: <?php
        if (isset($smls_settings['arrow_hover_color'])) {
            echo esc_attr($smls_settings['arrow_hover_color']);
        } else {
            echo '#f24831';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-3.owl-theme .owl-controls .owl-nav [class*=owl-]:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-3 .bx-controls-direction a:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-prev:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-3 a.flipto-next:hover {
        border-color: <?php
        if (isset($smls_settings['arrow_hover_color'])) {
            echo esc_attr($smls_settings['arrow_hover_color']);
        } else {
            echo '#f24831';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-4.owl-theme .owl-controls .owl-nav [class*=owl-], .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-4 .bx-controls-direction a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-4 a.flipto-prev, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-4 a.flipto-next {

        border: 2px solid <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#cccccc';
        }
        ?>;
        color: <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#cccccc';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-4.owl-carousel .owl-controls .owl-nav [class*=owl-]:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-4 .bx-controls-direction a:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-4 a.flipto-prev:hover, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-4 a.flipto-next:hover {
        background-color: <?php
        if (isset($smls_settings['arrow_hover_color'])) {
            echo esc_attr($smls_settings['arrow_hover_color']);
        } else {
            echo '#e8e8e8';
        }
        ?>;
        color: #333333;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-arrow-type-5.owl-theme .owl-controls .owl-nav [class*=owl-], .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-vertical-wrapper .smls-carousel-arrow-type-5 .bx-controls-direction a, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-5 a.flipto-prev, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective.smls-carousel-arrow-type-5 a.flipto-next {
        background-color:  <?php
        if (isset($smls_settings['arrow_color'])) {
            echo esc_attr($smls_settings['arrow_color']);
        } else {
            echo '#75be08';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-list-container-template-1 .smls-list-title, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-list-container-template-2 .smls-list-title {
        font-size: <?php
        if (isset($smls_settings['list_title_font_size'])) {
            echo esc_attr($smls_settings['list_title_font_size']);
        } else {
            echo '18';
        }
        ?>px;
        color: <?php
        if (isset($smls_settings['list_title_color'])) {
            echo esc_attr($smls_settings['list_title_color']);
        } else {
            echo '#000000';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-list-container-template-1 .smls-list-description, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-list-container-template-2 .smls-list-description {
        font-size:  <?php
        if (isset($smls_settings['list_desc_font_size'])) {
            echo esc_attr($smls_settings['list_desc_font_size']);
        } else {
            echo '14';
        }
        ?>px;
        color:  <?php
        if (isset($smls_settings['list_desc_color'])) {
            echo esc_attr($smls_settings['list_desc_color']);
        } else {
            echo '#666666';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-perspective-template-4 .smls-flip-four-title {
        background-color:  <?php
        if (isset($smls_settings['perspective_bg_color'])) {
            echo esc_attr($smls_settings['perspective_bg_color']);
        } else {
            echo '#75bd07';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-4.owl-carousel .smls-carousel-four-items {
        border: 1px solid  <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;
    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-8.owl-carousel .owl-item.active .smls-row-wrap .smls-row-image:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-9.owl-carousel .owl-item .smls-row-wrap .smls-row-image:before {

        background-color: <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-8.owl-carousel .owl-item.active .smls-row-wrap .smls-row-image:after, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-9.owl-carousel .owl-item .smls-row-wrap .smls-row-image:after {

        background-color: <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-template-9.owl-carousel .owl-stage-outer {
        border: 1px solid <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;

    }
    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-logo.smls-carousel-template-10 {
        border: 1px solid <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;
    }

    .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-logo.smls-carousel-template-10[class*=smls-carousel-arrow-type-]:before, .smls-main-logo-outer-<?php echo $random_num; ?> .smls-carousel-logo.smls-carousel-template-10.smls-text-arrow:before {
        background-color: <?php
        if (isset($smls_settings['car_border_color'])) {
            echo esc_attr($smls_settings['car_border_color']);
        } else {
            echo '#eee';
        }
        ?>;
    }
</style>