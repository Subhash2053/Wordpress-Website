<?php
defined('ABSPATH') or die("No script kiddies please!");
global $post;
$post_id = $post->ID;
$smls_option = get_post_meta($post_id, 'smls_option', true);
//$this->print_array($smls_option);
?>
<label><?php _e('Logo Type', SMLS_TD); ?></label>
<div class="smls-logo-backend-wrapper">
    <div class="smls-logo-type-field">
        <form method="post" action="">
            <select name="smls_option[smls_logo_type]" class="smls-logo-type">
                <option value="without_filter"  <?php if (isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'without_filter') echo 'selected=="selected"'; ?>><?php _e('Without Filter', SMLS_TD) ?></option>
                <option value="with_filter"  <?php if (isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'with_filter') echo 'selected=="selected"'; ?>><?php _e('With Filter', SMLS_TD) ?></option>
            </select>
        </form>
    </div>
    <div class="smls-add-single-logo-wrap" style="display:none;">
        <input type="button" class="button-primary smls-add-logo-button" value="<?php _e('Add Logo', SMLS_TD); ?>">
        <div class="smls-add-append-wrap clearfix">
            <?php
            if (isset($smls_option['logo']) && is_array($smls_option['logo'])) {
                $smls_logo_count = count($smls_option['logo']);
            } else {
                $smls_logo_count = 0;
            }
            if ($smls_logo_count > 0) {
                if ($smls_option['smls_logo_type'] == 'without_filter') {
                    foreach ($smls_option['logo'] as $logo_key => $logo_detail) {
                        include(SMLS_PATH . 'inc/admin/smls-forms/smls-form-detail.php');
                    }
                }
            }
            ?>
        </div>
    </div>
    <div class="smls-add-category-logo-wrap" style="display:none;">
        <div class="smls-error-message" style="display: none;">
<?php _e('Enter filter name', SMLS_TD); ?>
        </div>
        <input type="text" name="" class="smls-filter-name" value="" placeholder="Filter name">
        <input type="button" class="button-primary smls-add-category-button" value="<?php _e('Add Filter', SMLS_TD); ?>">
        <input type="button" class="button-primary smls-add-logo-button" value="<?php _e('Add Logo', SMLS_TD); ?>">
        <div class="smls-category-wrap">
            <ul class="smls-tab-wrap">
                <?php
                if (isset($smls_option['logo']['filter_detail'])) {
                    $count = 0;
                    foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) {
                        $count++;
                        ?>
                        <li data-filter-key-ref="<?php echo esc_attr($filter_key); ?>" class="smls-tab-trigger <?php if ($count == 1) {
                            echo "smls-tab-active-trigger";
                        } ?>"> <input type="hidden" value="<?php if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                            echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                        } ?>" name=smls_option[logo][filter_detail][<?php echo $filter_key; ?>][filter_name]><?php if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                    echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                } ?><div class="smls-filter-remover"><span class="dashicons dashicons-no"></span></div></li>
                    <?php }
                }
                ?>
            </ul>
        </div>
        <div class="smls-form-field-container">
            <div class="smls-form-field-holder">
                        <?php
                        if (isset($smls_option['logo']['filter_detail'])) {
                            $count = 0;
                            foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) {
                                $count++;
                                ?>
                        <div class="smls-each-filter-wrap" data-filter-key-ref="<?php echo esc_attr($filter_key); ?>" <?php if ($count == 1) { ?> style="display: block;" <?php } else { ?> style="display: none;" <?php } ?>>
                            <div class="smls-add-append-wrap clearfix">
        <?php
        if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'])) {
            foreach ($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'] as $logo_key => $logo_detail) {
                include(SMLS_PATH . 'inc/admin/smls-forms/smls-form-detail.php');
            }
        }
        ?>
                            </div>
                        </div>
    <?php }
}
?>
            </div>
        </div>
    </div>
</div>
<input type="hidden" value="" id="smls-filter-collection">
