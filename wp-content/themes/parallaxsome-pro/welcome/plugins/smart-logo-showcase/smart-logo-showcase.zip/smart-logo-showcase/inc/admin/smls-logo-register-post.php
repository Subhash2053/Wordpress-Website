<?php 
defined('ABSPATH') or die("No script kiddies please!");
$labels = array(
		'name'               => _x( 'Smart Logo', 'post type general name', 'smart-logo-showcase' ),
		'singular_name'      => _x( 'Smart Logo', 'post type singular name', 'smart-logo-showcase' ),
		'menu_name'          => _x( 'Smart Logo', 'admin menu', 'smart-logo-showcase' ),
		'name_admin_bar'     => _x( 'Smart Logo', 'add new on admin bar', 'smart-logo-showcase' ),
		'add_new'            => _x( 'Add New', 'Smart Logo', 'smart-logo-showcase' ),
		'add_new_item'       => __( 'Add New Smart Logo', 'smart-logo-showcase' ),
		'new_item'           => __( 'New Smart Logo', 'smart-logo-showcase' ),
		'edit_item'          => __( 'Edit Smart Logo', 'smart-logo-showcase' ),
		'view_item'          => __( 'View Smart Logo', 'smart-logo-showcase' ),
		'all_items'          => __( 'All Smart Logo', 'smart-logo-showcase' ),
		'search_items'       => __( 'Search Smart Logo', 'smart-logo-showcase' ),
		'parent_item_colon'  => __( 'Parent Smart Logo:', 'smart-logo-showcase' ),
		'not_found'          => __( 'No Smart Logo found.', 'smart-logo-showcase' ),
		'not_found_in_trash' => __( 'No Smart Logo found in Trash.', 'smart-logo-showcase' )
	);

	$args = array(
		'labels'             => $labels,
                'description'        => __( 'Description.', 'smart-logo-showcase' ),
		'public'             => false,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'   		 => 'dashicons-slides',
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'smart-logo-showcase' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title')
	);

	