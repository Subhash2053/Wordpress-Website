<?php
defined('ABSPATH') or die("No script kiddies please!");
$image_url = $_POST['image_url'];
$image_id = $_POST['image_id'];
$logo_type = $_POST['logo_type'];
$logo_key = $this->smls_generate_random_string(15);
$logo = 'logo_' . $logo_key;
if ($logo_type == 'with_filter') {
    $smls_field_prefix = "smls_option[logo][filter_detail][" . sanitize_text_field($_POST['active_filter_key']) . "][filter_logo][logo_$logo_key]";
} else {
    $smls_field_prefix = "smls_option[logo][logo_$logo_key]";
}
?>
<div class="smls-each-logo-item" data-logo-key="<?php echo esc_attr($logo); ?>">
    <div class="smls-logo-image-preview">
        <div class="smls-each-logo-actions-wrap clearfix">
            <a href="javascript:void(0)" class="smls-edit-logo"><span class="dashicons dashicons-edit"></span></a>
            <a href="javascript:void(0)" class="smls-move-logo"><span class="dashicons dashicons-move"></span></a>
            <a href="javascript:void(0)" class="smls-settings-logo"><span class="dashicons dashicons-admin-generic"></span></a>
            <a href="javascript:void(0)" class="smls-delete-logo"><span class="dashicons dashicons-trash"></span></a>
        </div>
        <div class="smls-setting-image">
            <img  class="smls-logo-image" src="<?php echo esc_attr($image_url); ?>" alt="" width="250">
            <input type="hidden" class="smls-logo-image-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_image_url]'); ?>"  value="<?php echo esc_attr($image_url); ?>" />
            <input type="hidden" class="smls-logo-image-id" name="<?php echo esc_attr($smls_field_prefix . '[logo_image_id]'); ?>"  value="<?php echo esc_attr($image_id); ?>" />
        </div>
    </div>
    <div class="smls-add-logo-option-wrap" style="display: none;">
        <div class="smls-setting-overlay"></div>
        <div class="smls-logo-item-detail-fields">
            <h4><?php _e('Logo Details', SMLS_TD); ?><span class="dashicons dashicons-no smls-close-popup"></span></h4>
            <div class="smls-option-wrapper">
                <label for="smls_logo_title" class="smls-logo-title"><?php _e('Logo Title', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <input type="text" class="smls-logo-title" name="<?php echo esc_attr($smls_field_prefix . '[title]'); ?>"  value=""/>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls_description_heading" class="smls-description-heading"><?php _e('Description Heading', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <input type="text" class="smls-desc-heading" name="<?php echo esc_attr($smls_field_prefix . '[description_heading]'); ?>"  value=""/>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls_sub_heading" class="smls-sub-heading"><?php _e('Sub Heading', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <input type="text" class="smls-sub-heading" name="<?php echo esc_attr($smls_field_prefix . '[sub_heading]'); ?>"  value=""/>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls_logo_description" class="smls-logo-description"><?php _e('Company Description', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <textarea name="<?php echo esc_attr($smls_field_prefix . '[logo_description]'); ?>"  class="smls-logo-description" rows="15" cols="35"></textarea>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls_logo_image_gallery" class="smls-logo-image-gallery"><?php _e('Image Gallery', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <input type="button" class="smls-logo-image-gallery-url-button" name="smls_logo_image_gallery_url_button"  value="Upload Images" size="25"/>
                    <div class="smls-image-url-collect clearfix">

                    </div>

                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls-show-contact-info" class="smls-show-logo-social-link"><?php _e('Contact Info', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <label class="smls-logo-contact-info-check"><input type="checkbox" class="smls-logo-contact-info"><?php _e('Check to show contact details', SMLS_TD) ?></label>
                    <input type="hidden" name="<?php echo esc_attr($smls_field_prefix . '[logo_contact_details]'); ?>" class="smls-logo-contact-info-value" value="0">
                </div>
            </div>
            <div class="smls-contact-detail-wrap"  style="display: none;">
                <div class="smls-option-wrapper">
                    <label for="smls_contact_heading" class="smls-contact-heading"><?php _e('Contact Heading', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-contact-heading" name="<?php echo esc_attr($smls_field_prefix . '[contact_heading]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_company_name" class="smls-logo-company-name"><?php _e('Company Name', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-company-name" name="<?php echo esc_attr($smls_field_prefix . '[company_name]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_company_address" class="smls-logo-company-address"><?php _e('Company Address', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-company-address" name="<?php echo esc_attr($smls_field_prefix . '[company_address]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_company_url" class="smls-logo-company-url"><?php _e('Company URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-company-url" name="<?php echo esc_attr($smls_field_prefix . '[company_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_company_email"><?php _e('Email Address', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="email" class="smls-company-email" name="<?php echo esc_attr($smls_field_prefix . '[company_email]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_contact_number"><?php _e('Contact number', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="tel" class="smls-contact-number" name="<?php echo esc_attr($smls_field_prefix . '[contact_number]'); ?>"  value=""/>
                    </div>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls-show-logo-social-link" class="smls-show-logo-social-link"><?php _e('Social Icon', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <label class="smls-logo-social-icon-check"><input type="checkbox" class="smls-logo-social-icon"><?php _e('Check to show your social links', SMLS_TD) ?></label>
                    <input type="hidden" name="<?php echo esc_attr($smls_field_prefix . '[logo_social_icon]'); ?>" class="smls-logo-social-icon-value" value="0">
                </div>
            </div>
            <div class="smls-logo-bsocial-wrap" style="display: none;">   <div class="smls-option-wrapper">
                    <label for="smls_logo_facebook_url" class="smls-logo-fb-url"><?php _e('Facebook URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-fb-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_facebook_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_twitter_url" class="smls-logo-twitter-url"><?php _e('Twitter URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-twitter-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_twitter_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_linkedin_url" class="smls-logo-linkedin-url"><?php _e('Linkedin URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-linkedin-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_linkedin_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_skype_url" class="smls-logo-skype-url"><?php _e('Skype URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-skype-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_skype_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_instagram_url" class="smls-logo-instagram-url"><?php _e('Instagram URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-instagram-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_instagram_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_gplus_url" class="smls-logo-gplus-url"><?php _e('Gplus URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-gplus-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_gplus_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_pinterest_url" class="smls-logo-pinterest-url"><?php _e('Pinterest URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-pinterest-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_pinterest_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_tumblr_url" class="smls-logo-tumblr-url"><?php _e('Tumblr URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-tumblr-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_tumblr_url]'); ?>"  value=""/>
                    </div>
                </div>
                <div class="smls-option-wrapper">
                    <label for="smls_logo_youtube_url" class="smls-logo-youtube-url"><?php _e('Youtube URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-youtube-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_youtube_url]'); ?>"  value=""/>
                    </div>
                </div>
            </div>
            <div class="smls-option-wrapper">
                <label for="smls-show-link-info" class="smls-show-external-link"><?php _e('External Link', SMLS_TD); ?></label>
                <div class="smls-option-field">
                    <label class="smls-logo-external-link-check"><input type="checkbox" class="smls-logo-external-link-info" <?php checked($smls_value_prefix['logo_external_link'], 1) ?>><?php _e('Check to show external link', SMLS_TD) ?></label>
                    <input type="hidden" name="<?php echo esc_attr($smls_field_prefix . '[logo_external_link]'); ?>" class="smls-logo-external-link-value" value="">
                </div>
            </div>
            <div class="smls-external-link-wrap" style="display: none;">
                <div class="smls-option-wrapper">
                    <label for="smls_external_link" class="smls-logo-external_url">
                        <?php _e('External URL', SMLS_TD); ?></label>
                    <div class="smls-option-field">
                        <input type="text" class="smls-logo-
                               external-url" name="<?php echo esc_attr($smls_field_prefix . '[logo_external_url]'); ?>"  value=""/>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

