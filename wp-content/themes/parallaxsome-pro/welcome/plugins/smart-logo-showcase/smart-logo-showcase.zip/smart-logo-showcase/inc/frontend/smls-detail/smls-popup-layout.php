<?php
defined('ABSPATH') or die("No script kiddies please!");
$logo_ran_num = rand(222222222, 999999999);
if (isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'without_filter') {
    $smls_value = $smls_option['logo'][$logo_key];
    $smls_image = $smls_value['logo_image_url'];
} else {
    $smls_value = $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key];
    if (isset($smls_settings['filter_type']) && $smls_settings['filter_type'] == 'normal') {
        $smls_image = $crop_image[0];
    } else {
        $smls_image = $smls_value['logo_image_url'];
    }
}
if (isset($smls_settings['logo_layout']) && $smls_settings['logo_layout'] == 'carousel' || $smls_settings['logo_layout'] == 'list' || $smls_settings['logo_layout'] == 'perspective' || isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'with_filter') {
    ?>
    <div class="smls-popup-wrap <?php
    if ($smls_value['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'popup')) {
        echo ' smls-icon-center';
    }
    if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'popup' || $smls_value['logo_external_link'] == 1)) {
        echo ' smls-overlay-title-center';
    }
    ?>">
         <?php } else {
             ?>
        <div class="smls-popup-wrap <?php
        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
            echo 'smls-tooltip';
        }
        if ($smls_value['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'popup')) {
            echo ' smls-icon-center';
        } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'popup' || $smls_value['logo_external_link'] == 1)) {
            echo ' smls-overlay-title-center';
        }
        ?>" <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
            ?>
                 title="<?php
                 if (isset($smls_value['title'])) {
                     echo esc_attr($smls_value['title']);
                 }
                 ?>"  data-id="smls_<?php
                 echo rand(111111111, 999999999);
                 ?>"
                 data-template="<?php
                 if (isset($smls_settings['tooltip_template'])) {
                     echo esc_attr($smls_settings['tooltip_template']);
                 }
                 ?>"
                 data-position="<?php
                 if (isset($smls_settings['tooltip_position'])) {
                     echo esc_attr($smls_settings['tooltip_position']);
                 }
                 ?>"
                 data-animation="<?php
                 if (isset($smls_settings['tooltip_animation'])) {
                     echo esc_attr($smls_settings['tooltip_animation']);
                 }
                 ?>"
                 data-duration="<?php
                 if (isset($smls_settings['tooltip_duration'])) {
                     echo esc_attr($smls_settings['tooltip_duration']);
                 }
                 ?>"
                 <?php
             }
             ?>>
             <?php } ?>

        <div class="smls-only-image-wrap">
            <?php if ($smls_settings['logo_image_effects'] == 'overlay') {
                ?>
                <img <?php if (isset($smls_settings['filter_type']) && $smls_settings['filter_type'] == 'blur') { ?>
                        data-src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>"
                    <?php } ?> src="<?php echo esc_attr($smls_image); ?>">
                <div class="smls-overlay-all-wrap">
                    <?php
                    if ($smls_settings['logo_title_view'] == 'title_overlay') {
                        if (!empty($smls_value['title'])) {
                            ?>
                            <div class="smls-overlay-title">
                                <?php
                                if (isset($smls_value['title'])) {
                                    echo esc_attr($smls_value['title']);
                                }
                                ?>
                            </div>
                            <?php
                        }
                    }
                    if (isset($smls_value['logo_external_link']) && $smls_value['logo_external_link'] == 1) {
                        ?>
                        <a class="smls-link-style" href="<?php
                        if (isset($smls_value['logo_external_link'])) {
                            echo esc_url($smls_value['logo_external_url']);
                        }
                        ?>" target="_blank"> <span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                           <?php
                       }
                       ?>
                    <a class="smls-popup-icon" href="#smls-popup-inline-<?php echo esc_attr($logo_ran_num); ?>" rel="smls-popup" >
                        <span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                </div>
                <div class="smls-overlay-wrap"></div>
            <?php } else {
                ?>
                <a class="smls-popup-tag" href="#smls-popup-inline-<?php echo esc_attr($logo_ran_num); ?>" rel="smls-popup" >
                    <img <?php if (isset($smls_settings['filter_type']) && $smls_settings['filter_type'] == 'blur') { ?>
                            data-src="<?php echo $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']; ?>"
                        <?php } ?> src="<?php echo esc_attr($smls_image); ?>">
                </a>
                <?php
            }
            ?>
        </div>
        <div id="smls-popup-inline-<?php echo esc_attr($logo_ran_num); ?>" class="smls-hide">
            <div class="smls-popup-content-wrap smls-popup-<?php echo esc_attr($smls_settings['popup_template']); ?>">
                <div class="smls-first-content-wrap clearfix">
                    <div class="smls-popup-logo-image">
                        <img src="<?php echo esc_attr($smls_value['logo_image_url']); ?>">
                    </div>
                    <div class="smls-only-content-wrap">
                        <div class="smls-logo-description-heading">
                            <?php
                            if (isset($smls_value['description_heading'])) {
                                echo esc_attr($smls_value['description_heading']);
                            }
                            ?>
                        </div>
                        <div class="smls-logo-sub-heading">
                            <?php
                            if (isset($smls_value['sub_heading'])) {
                                echo esc_attr($smls_value['sub_heading']);
                            }
                            ?>
                        </div>
                        <div class="smls-logo-description">

                            <?php
                            if (isset($smls_value['logo_description'])) {
                                echo esc_attr($smls_value['logo_description']);
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <?php if (isset($smls_settings['popup_template']) && $smls_settings['popup_template'] == 'template-2') { ?>
                    <div class="smls-inline-gallery-detail-wrap">
                        <?php
                        if (isset($smls_value['gallery_detail'])) {
                            foreach ($smls_value['gallery_detail'] as $gallery_key => $detail) {
                                ?>
                                <a href="<?php
                                if (isset($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                    echo esc_url($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                }
                                ?>" data-smlslightbox="gallery"><img src="<?php
                                       if (isset($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                           echo esc_attr($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                       }
                                       ?>" width="100" height="100" alt="" /></a>
                                    <?php
                                }
                            }
                            ?>
                    </div>
                <?php } ?>
                <div class="smls-popup-second-content-wrap clearfix">
                    <div class="smls-popup-third-content-wrap clearfix">
                        <?php if (isset($smls_value['logo_contact_details']) && $smls_value['logo_contact_details'] == 1) { ?>
                            <div class="smls-contact-wrap">
                                <?php if(!empty($smls_value['contact_heading'])) { ?>
                                <div class="smls-contact-heading">
                                    <?php
                                    if (isset($smls_value['contact_heading'])) {
                                        echo esc_attr($smls_value['contact_heading']);
                                    }
                                    ?>
                                </div>
                                <?php } 
                                if (isset($smls_value['company_name'])) { ?>
                                    <div class="smls-company-name">

                                        <?php echo esc_attr($smls_value['company_name']); ?>
                                    </div>
                                    <?php
                                }
                                if (isset($smls_settings['popup_template']) && $smls_settings['popup_template'] == 'template-2') {
                                    ?> <div class="smls-popup-template2-wrap clearfix">
                                    <?php
                                }
                                if (!empty($smls_value['company_address'])) {
                                    ?>
                                        <div class="smls-company-address">
                                            <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                                            <p><?php echo esc_attr($smls_value['company_address']); ?>
                                            </p>
                                        </div>
                                        <?php
                                    }

                                    if (!empty($smls_value['contact_number'])) {
                                        ?>

                                        <div class="smls-company-contact-number">
                                            <span><i class="fa fa-mobile" aria-hidden="true"></i></span>
                                            <p>
                                                <?php echo esc_attr($smls_value['contact_number']); ?>
                                            </p>
                                        </div>

                                        <?php
                                    }
                                    if (!empty($smls_value['company_email'])) {
                                        ?>
                                        <div class="smls-company-email">
                                            <span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                                            <p>
                                                <a href="mailto:<?php echo esc_attr($smls_value['company_email']); ?>" target="_top"><?php echo esc_attr($smls_value['company_email']); ?></a>
                                            </p>
                                        </div>
                                        <?php
                                    }
                                    if (!empty($smls_value['company_url'])) {
                                        ?>

                                        <div class="smls-company-url">
                                            <span><i class="fa fa-globe" aria-hidden="true"></i></span>
                                            <p>
                                                <a href="<?php echo esc_url($smls_value['company_url']); ?>" target="_blank">
                                                    <?php echo esc_attr($smls_value['company_url']); ?>
                                                </a>
                                            </p>
                                        </div>
                                        <?php
                                    }

                                    if (isset($smls_settings['popup_template']) && $smls_settings['popup_template'] == 'template-2') {
                                        ?> </div>
                                <?php } ?>

                            </div>
                            <?php
                        }
                        if (isset($smls_value['logo_social_icon']) && $smls_value['logo_social_icon'] == 1) {
                            ?>
                            <div class="smls-social-icon-wrap">
                                <?php if (!empty($smls_value['logo_facebook_url'])) { ?>
                                    <a class="smls-fb-link" href="<?php echo esc_url($smls_value['logo_facebook_url']); ?>" target="_blank">
                                        <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_twitter_url'])) { ?>
                                    <a class="smls-twitter-link" href="<?php echo esc_url($smls_value['logo_twitter_url']); ?>" target="_blank">
                                        <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_linkedin_url'])) { ?>
                                    <a class="smls-linkedin-link" href="<?php echo esc_url($smls_value['logo_linkedin_url']); ?>" target="_blank">
                                        <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_instagram_url'])) { ?>
                                    <a class="smls-instagram-link" href="<?php echo esc_url($smls_value['logo_instagram_url']); ?>" target="_blank">
                                        <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_gplus_url'])) { ?>
                                    <a class="smls-gplus-link" href="<?php echo esc_url($smls_value['logo_gplus_url']); ?>" target="_blank">
                                        <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_skype_url'])) { ?>
                                    <a class="smls-skype-link" href="<?php echo esc_url($smls_value['logo_skype_url']); ?>" target="_blank">
                                        <i class="fa fa-skype" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_youtube_url'])) { ?>
                                    <a class="smls-youtube-link" href="<?php echo esc_url($smls_value['logo_youtube_url']); ?>" target="_blank">
                                        <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_pinterest_url'])) { ?>
                                    <a class="smls-pinterest-link" href="<?php echo esc_url($smls_value['logo_pinterest_url']); ?>" target="_blank">
                                        <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_value['logo_tumblr_url'])) { ?>
                                    <a class="smls-tumblr-link" href="<?php echo esc_url($smls_value['logo_tumblr_url']); ?>" target="_blank">
                                        <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                <?php } ?>
                            </div>
                        <?php } ?>
                    </div>
                    <?php if (isset($smls_settings['popup_template']) && $smls_settings['popup_template'] == 'template-1') { ?>
                        <div class="smls-inline-gallery-detail-wrap">
                            <?php
                            if (isset($smls_value['gallery_detail'])) {
                                foreach ($smls_value['gallery_detail'] as $gallery_key => $detail) {
                                    ?>
                                    <a href="<?php
                                    if (isset($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                        echo esc_attr($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                    }
                                    ?>" data-smlslightbox="gallery"><img src="<?php
                                           if (isset($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                               echo esc_attr($smls_value['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                           }
                                           ?>" width="100" height="100" alt="" /></a>
                                        <?php
                                    }
                                }
                                ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
