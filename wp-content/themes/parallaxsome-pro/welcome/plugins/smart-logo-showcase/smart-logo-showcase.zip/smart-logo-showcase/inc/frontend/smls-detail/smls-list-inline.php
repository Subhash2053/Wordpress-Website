<div class="smls-list-inline-wrap clearfix" style="display:none;">
    <div class="smls-list-inline-contact">
        <?php if (isset($smls_option['logo'][$logo_key]['logo_contact_details']) && $smls_option['logo'][$logo_key]['logo_contact_details'] == 1) { ?>
            <div class="smls-list-contact-wrap">
                <div class="smls-list-contact-heading">
                    <?php
                    if (isset($smls_option['logo'][$logo_key]['contact_heading'])) {
                        echo esc_attr($smls_option['logo'][$logo_key]['contact_heading']);
                    }
                    ?>
                </div>
                <div class="smls-list-company-name">
                    <?php
                    if (isset($smls_option['logo'][$logo_key]['company_name'])) {
                        echo esc_attr($smls_option['logo'][$logo_key]['company_name']);
                    }
                    ?>
                </div>
                <?php if(!empty($smls_option['logo'][$logo_key]['company_address'])) { ?>
                <div class="smls-list-company-address clearfix">
                    <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                    <?php if (isset($smls_option['logo'][$logo_key]['company_address'])) { ?>
                        <p>
                            <?php echo esc_attr($smls_option['logo'][$logo_key]['company_address']); ?>
                        </p>
                        <?php
                    }
                    ?>
                </div>
                <?php } 
                 if(!empty($smls_option['logo'][$logo_key]['contact_number'])) { ?>
                <div class="smls-list-company-contact-number clearfix">
                    <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                    <?php
                    if (isset($smls_option['logo'][$logo_key]['contact_number'])) {
                        ?><p><?php echo esc_attr($smls_option['logo'][$logo_key]['contact_number']); ?>
                        </p><?php
                    }
                    ?>
                </div>
                <?php } 
                if(!empty($smls_option['logo'][$logo_key]['company_email'])) { ?>
                <div class="smls-list-company-email clearfix">
                    <span><i class="fa fa-paper-plane" aria-hidden="true"></i></span>
                    <?php if (isset($smls_option['logo'][$logo_key]['company_email'])) { ?>
                        <p>
                            <a href="mailto:<?php echo esc_attr($smls_option['logo'][$logo_key]['company_email']); ?>" target="_top"><?php echo esc_attr($smls_option['logo'][$logo_key]['company_email']); ?></a>
                        </p>
                    <?php }
                    ?>
                </div>
                <?php }  
                if(!empty($smls_option['logo'][$logo_key]['company_url'])) { ?>
                <div class="smls-list-company-url clearfix">
                    <span><i class="fa fa-globe" aria-hidden="true"></i></span>
                    <?php if (isset($smls_option['logo'][$logo_key]['company_url'])) { ?>
                        <p><a href=" <?php echo esc_url($smls_option['logo'][$logo_key]['company_url']); ?>" target="_blank"><?php echo esc_attr($smls_option['logo'][$logo_key]['company_url']); ?></a>

                        </p><?php
                    }
                    ?>
                </div>
                <?php } ?>
            </div>

        <?php } ?>
    </div>
    <div class="smls-list-inline-gallery">
        <?php
        if (isset($smls_option['logo'][$logo_key]['gallery_detail'])) {
            foreach ($smls_option['logo'][$logo_key]['gallery_detail'] as $gallery_key => $detail) {
                ?>
                <a href="<?php
                if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                    echo esc_attr($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                }
                ?>" data-smlslightbox="gallery"><img src="<?php
                       if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                           echo esc_attr($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                       }
                       ?>" width="100" height="100" alt="" /></a>
                    <?php
                }
            }
            ?>
    </div>
</div>