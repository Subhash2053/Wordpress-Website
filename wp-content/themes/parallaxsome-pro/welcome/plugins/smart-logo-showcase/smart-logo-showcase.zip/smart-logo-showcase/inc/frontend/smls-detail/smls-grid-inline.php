<?php
defined('ABSPATH') or die("No script kiddies please!");
$shortcode_id = sanitize_text_field($_POST['shortcode_id']);
$logo_key = sanitize_text_field($_POST['logo_key']);
$logo_type = sanitize_text_field($_POST['logo_type']);
$smls_option = get_post_meta($shortcode_id, 'smls_option', true);
$smls_settings = get_post_meta($shortcode_id, 'smls_settings', true);
$smls_logo_type_prefix = $smls_option['logo'][$logo_key];
?>
<div class="smls-logo-inline-wrap smls-inline-<?php echo esc_attr($smls_settings['inline_layout']); ?>" style="display:none;">
    <div class="smls-logo-inline-slideup">
        <div class="smls-logo-inline-delete"><i class="fa fa-times" aria-hidden="true"></i></div>
        <?php if (isset($smls_settings['inline_layout']) && $smls_settings['inline_layout'] == 'template-1') {
            ?>

            <div class="smls-logo-inline-description-block">

                <?php if (!empty($smls_logo_type_prefix['description_heading'])) { ?>
                    <div class="smls-logo-inline-title"><?php echo esc_attr($smls_logo_type_prefix['description_heading']); ?>
                    </div><?php
                }
                ?>

                <?php if (isset($smls_logo_type_prefix['logo_description'])) { ?>
                    <div class="smls-inline-description"><?php echo esc_attr($smls_logo_type_prefix['logo_description']); ?>
                    </div>
                <?php }
                ?>
            </div>
            <div class="smls-content-block-template-1 clearfix">
                <div class="smls-contact-block-template-1">
                    <?php if (isset($smls_logo_type_prefix['logo_contact_details']) && $smls_logo_type_prefix['logo_contact_details'] == 1) { ?>
                        <div class="smls-contact-wrap">
                            <?php if (!empty($smls_logo_type_prefix['contact_heading'])) { ?>
                            <div class="smls-contact-heading">
                                <?php
                                if (isset($smls_logo_type_prefix['contact_heading'])) {
                                    echo esc_attr($smls_logo_type_prefix['contact_heading']);
                                }
                                ?>
                            </div>
                            <?php } ?>
                            <div class="smls-company-name">
                                <?php
                                if (isset($smls_logo_type_prefix['company_name'])) {
                                    echo esc_attr($smls_logo_type_prefix['company_name']);
                                }
                                ?>
                            </div>
                            <?php if(!empty($smls_logo_type_prefix['company_address'])) { ?>
                            <div class="smls-company-address">
                                <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                                <?php if (isset($smls_logo_type_prefix['company_address'])) { ?>
                                    <p>
                                        <?php echo esc_attr($smls_logo_type_prefix['company_address']); ?>
                                    </p>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php }
                             if(!empty($smls_logo_type_prefix['contact_number'])) { ?>
                            <div class="smls-company-contact-number">
                                <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                                <?php
                                if (isset($smls_logo_type_prefix['contact_number'])) {
                                    ?><p><?php echo esc_attr($smls_logo_type_prefix['contact_number']); ?>
                                    </p><?php
                                }
                                ?>
                            </div>
                            <?php } 
                             if(!empty($smls_logo_type_prefix['company_email'])) { ?>
                            <div class="smls-company-email">
                                <span><i class="fa fa-paper-plane" aria-hidden="true"></i></span>
                                <?php if (isset($smls_logo_type_prefix['company_email'])) { ?>
                                    <p>
                                        <a href="mailto:<?php echo esc_attr($smls_logo_type_prefix['company_email']); ?>" target="_top"><?php echo esc_attr($smls_logo_type_prefix['company_email']); ?></a>
                                    </p>
                                <?php }
                                ?>
                            </div>
                            <?php }
                               if(!empty($smls_logo_type_prefix['company_url'])) { ?>
                            <div class="smls-company-url">
                                <span><i class="fa fa-globe" aria-hidden="true"></i></span>

                                <?php if (isset($smls_logo_type_prefix['company_url'])) { ?>
                                    <a href="<?php echo esc_attr($smls_logo_type_prefix['company_url']); ?>" target="_blank">
                                        <p><?php echo esc_url($smls_logo_type_prefix['company_url']); ?>
                                        </p>
                                    </a><?php
                                }
                                ?>
                            </div>

                        <?php } } ?>
                    </div>
                    <?php
                    if (isset($smls_logo_type_prefix['logo_social_icon']) && $smls_logo_type_prefix['logo_social_icon'] == 1) {
                        ?>
                        <div class="smls-social-icon-wrap">
                            <?php if (!empty($smls_logo_type_prefix['logo_facebook_url'])) { ?>
                                <a class="smls-fb-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_facebook_url']); ?>" target="_blank">
                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_twitter_url'])) { ?>
                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_twitter_url']); ?>" target="_blank">
                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_linkedin_url'])) { ?>
                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_linkedin_url']); ?>" target="_blank">
                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_instagram_url'])) { ?>
                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_instagram_url']); ?>" target="_blank">
                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_gplus_url'])) { ?>
                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_gplus_url']); ?>" target="_blank">
                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_skype_url'])) { ?>
                                <a class="smls-skype-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_skype_url']); ?>" target="_blank">
                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_youtube_url'])) { ?>
                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_youtube_url']); ?>" target="_blank">
                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_pinterest_url'])) { ?>
                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_pinterest_url']); ?>" target="_blank">
                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                            <?php } ?>
                            <?php if (!empty($smls_logo_type_prefix['logo_tumblr_url'])) { ?>
                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_tumblr_url']); ?>" target="_blank">
                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
                <div class="smls-inline-gallery-detail-wrap-template-1">
                    <?php
                    if (isset($smls_logo_type_prefix['gallery_detail'])) {
                        foreach ($smls_logo_type_prefix['gallery_detail'] as $gallery_key => $detail) {
                            ?>
                            <a href="<?php
                            if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                            }
                            ?>" data-smlslightbox="gallery"><img src="<?php
                                   if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                       echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                   }
                                   ?>" width="100" height="100" alt="" /></a>
                                <?php
                            }
                        }
                        ?>
                </div>
            </div>
            <?php
        } else if (isset($smls_settings['inline_layout']) && $smls_settings['inline_layout'] == 'template-2') {
            ?>
            <div class="smls-inline-template-2-main-wrap">
                <div class="smls-content-wrap-template-2 clearfix">

                    <div class="smls-logo-inline-description-wrap">
                        <?php if (!empty($smls_logo_type_prefix['description_heading'])) { ?>
                            <div class="smls-logo-inline-title">

                                <?php echo esc_attr($smls_logo_type_prefix['description_heading']); ?>
                            </div>
                            <?php
                        }
                        if (isset($smls_logo_type_prefix['logo_description'])) {
                            ?>
                            <div class="smls-inline-description">
                                <?php echo esc_attr($smls_logo_type_prefix['logo_description']); ?>
                            </div>
                        <?php }
                        ?>

                    </div>
                    <div class="smls-contact-wrapper-template-2">
                        <?php if (isset($smls_logo_type_prefix['logo_contact_details']) && $smls_logo_type_prefix['logo_contact_details'] == 1) { ?>
                            <div class="smls-contact-wrap">
                                   <?php if (!empty($smls_logo_type_prefix['contact_heading'])) { ?>
                                <div class="smls-contact-heading">
                                    <?php
                                    if (isset($smls_logo_type_prefix['contact_heading'])) {
                                        echo esc_attr($smls_logo_type_prefix['contact_heading']);
                                    }
                                    ?>
                                </div>
                                <?php } 
                                  if(!empty($smls_logo_type_prefix['company_name'])) { ?>
                                <div class="smls-company-name">
                                    <?php if (isset($smls_logo_type_prefix['company_name'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['company_name']); ?>
                                        </p>
                                    <?php }
                                    ?>
                                </div>
                                <?php } 
                                if(!empty($smls_logo_type_prefix['company_address'])){
                                ?>
                                <div class="smls-company-address">

                                    <?php if (isset($smls_logo_type_prefix['company_address'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['company_address']); ?>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php } 
                                if(!empty($smls_logo_type_prefix['contact_number'])){ ?>
                                <div class="smls-company-contact-number">
                                    <?php _e('Tel', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['contact_number'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['contact_number']); ?>
                                        </p><?php
                                    }
                                    ?>
                                </div>
                                <?php }  
                                if(!empty($smls_logo_type_prefix['company_email'])){ ?>
                                <div class="smls-company-email">
                                    <?php _e('Email', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['company_email'])) { ?>

                                        <p>
                                            <a href="mailto:<?php echo esc_attr($smls_logo_type_prefix['company_email']); ?>" target="_top"><?php echo esc_attr($smls_logo_type_prefix['company_email']); ?></a>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php } 
                                 if(!empty($smls_logo_type_prefix['company_url'])){ ?>
                                <div class="smls-company-url">
                                    <?php _e('Web', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['company_url'])) { ?>
                                        <p>
                                            <a href=" <?php echo esc_attr($smls_logo_type_prefix['company_url']); ?>" target="_blank">
                                                <?php echo esc_url($smls_logo_type_prefix['company_url']); ?>
                                            </a>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>

                            <?php }  } ?>
                        </div>
                        <?php
                        if (isset($smls_logo_type_prefix['logo_social_icon']) && $smls_logo_type_prefix['logo_social_icon'] == 1) {
                            ?>
                            <div class="smls-social-icon-wrap">
                                <?php if (!empty($smls_logo_type_prefix['logo_facebook_url'])) { ?>
                                    <a class="smls-fb-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_facebook_url']); ?>" target="_blank">
                                        <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_twitter_url'])) { ?>
                                    <a class="smls-twitter-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_twitter_url']); ?>" target="_blank">
                                        <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_linkedin_url'])) { ?>
                                    <a class="smls-linkedin-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_linkedin_url']); ?>" target="_blank">
                                        <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_instagram_url'])) { ?>
                                    <a class="smls-instagram-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_instagram_url']); ?>" target="_blank">
                                        <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_gplus_url'])) { ?>
                                    <a class="smls-gplus-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_gplus_url']); ?>" target="_blank">
                                        <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_skype_url'])) { ?>
                                    <a class="smls-skype-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_skype_url']); ?>" target="_blank">
                                        <i class="fa fa-skype" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_youtube_url'])) { ?>
                                    <a class="smls-youtube-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_youtube_url']); ?>" target="_blank">
                                        <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_pinterest_url'])) { ?>
                                    <a class="smls-pinterest-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_pinterest_url']); ?>" target="_blank">
                                        <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                <?php } ?>
                                <?php if (!empty($smls_logo_type_prefix['logo_tumblr_url'])) { ?>
                                    <a class="smls-tumblr-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_tumblr_url']); ?>" target="_blank">
                                        <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                <?php } ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="smls-gallery-wrap-template-2">
                    <?php
                    if (isset($smls_logo_type_prefix['gallery_detail'])) {
                        foreach ($smls_logo_type_prefix['gallery_detail'] as $gallery_key => $detail) {
                            ?>
                            <a href="<?php
                            if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                            }
                            ?>" data-smlslightbox="gallery"><img src="<?php
                                   if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                       echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                   }
                                   ?>" width="100" height="100" alt="" /></a>
                                <?php
                            }
                        }
                        ?>
                </div>
            </div>
            <?php
        } else {
            ?>
            <div class="smls-inline-template-3-wrap clearfix">
                <div class="smls-inline-three-content-wrap">
                    <div class="smls-inline-descp-wrap">
                        <?php if (!empty($smls_logo_type_prefix['description_heading'])) { ?>
                            <div class="smls-logo-inline-title">

                                <?php echo esc_attr($smls_logo_type_prefix['description_heading']); ?>
                            </div>
                        <?php }
                        ?>

                        <?php if (isset($smls_logo_type_prefix['logo_description'])) { ?>
                            <div class="smls-inline-description">
                                <?php echo esc_attr($smls_logo_type_prefix['logo_description']); ?>
                            </div>
                        <?php }
                        ?>
                    </div>
                    <div class="smls-inline-3-contact-wrap">
                        <?php if (isset($smls_logo_type_prefix['logo_contact_details']) && $smls_logo_type_prefix['logo_contact_details'] == 1) { ?>
                            <div class="smls-contact-wrap">
                                   <?php if (!empty($smls_logo_type_prefix['contact_heading'])) { ?>
                                <div class="smls-contact-heading">
                                    <?php
                                    if (isset($smls_logo_type_prefix['contact_heading'])) {
                                        echo esc_attr($smls_logo_type_prefix['contact_heading']);
                                    }
                                    ?>
                                </div>
                                <?php } 
                                if(!empty($smls_logo_type_prefix['company_name'])) { ?>
                                <div class="smls-company-name">
                                    <?php if (isset($smls_logo_type_prefix['company_name'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['company_name']); ?>
                                        </p>
                                    <?php }
                                    ?>
                                </div>
                                <?php } 
                                if(!empty($smls_logo_type_prefix['company_address'])) { ?>
                                <div class="smls-company-address">

                                    <?php if (isset($smls_logo_type_prefix['company_address'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['company_address']); ?>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php } 
                                  if(!empty($smls_logo_type_prefix['contact_number'])) { ?>
                                <div class="smls-company-contact-number">
                                    <?php _e('Tel', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['contact_number'])) { ?>
                                        <p><?php echo esc_attr($smls_logo_type_prefix['contact_number']); ?>
                                        </p><?php
                                    }
                                    ?>
                                </div>
                                <?php } 
                                  if(!empty($smls_logo_type_prefix['company_email'])) { ?>
                                <div class="smls-company-email">
                                    <?php _e('Email', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['company_email'])) { ?>
                                        <p>
                                            <a href="mailto:<?php echo esc_attr($smls_logo_type_prefix['company_email']); ?>" target="_top"><?php echo esc_attr($smls_logo_type_prefix['company_email']); ?></a>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php } 
                                if(!empty($smls_logo_type_prefix['company_url'])) { ?>
                                <div class="smls-company-url">
                                    <?php _e('Web', SMLS_TD); ?>
                                    <?php if (isset($smls_logo_type_prefix['company_url'])) { ?>
                                        <p>
                                            <a href="<?php echo esc_url($smls_logo_type_prefix['company_url']); ?>" target="_blank">
                                                <?php echo esc_attr($smls_logo_type_prefix['company_url']); ?>
                                            </a>
                                        </p>
                                        <?php
                                    }
                                    ?>
                                </div>
                            <?php } } ?>
                        </div>
                    </div>
                </div>
                <div class="smls-inline-3-gallery-wrap">
                    <?php
                    if (isset($smls_logo_type_prefix['gallery_detail'])) {
                        foreach ($smls_logo_type_prefix['gallery_detail'] as $gallery_key => $detail) {
                            ?>
                            <a href="<?php
                            if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                            }
                            ?>" data-smlslightbox="gallery"><img src="<?php
                                   if (isset($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                       echo esc_attr($smls_logo_type_prefix['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                   }
                                   ?>" width="100" height="100" alt="" /></a>
                                <?php
                            }
                        }
                        ?>
                </div>
                <?php
                if (isset($smls_logo_type_prefix['logo_social_icon']) && $smls_logo_type_prefix['logo_social_icon'] == 1) {
                    ?>
                    <div class="smls-social-icon-wrap">
                        <?php if (!empty($smls_logo_type_prefix['logo_facebook_url'])) { ?>
                            <a class="smls-fb-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_facebook_url']); ?>" target="_blank">
                                <i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_twitter_url'])) { ?>
                            <a class="smls-twitter-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_twitter_url']); ?>" target="_blank">
                                <i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_linkedin_url'])) { ?>
                            <a class="smls-linkedin-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_linkedin_url']); ?>" target="_blank">
                                <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_instagram_url'])) { ?>
                            <a class="smls-instagram-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_instagram_url']); ?>" target="_blank">
                                <i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_gplus_url'])) { ?>
                            <a class="smls-gplus-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_gplus_url']); ?>" target="_blank">
                                <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_skype_url'])) { ?>
                            <a class="smls-skype-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_skype_url']); ?>" target="_blank">
                                <i class="fa fa-skype" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_youtube_url'])) { ?>
                            <a class="smls-youtube-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_youtube_url']); ?>" target="_blank">
                                <i class="fa fa-youtube" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_pinterest_url'])) { ?>
                            <a class="smls-pinterest-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_pinterest_url']); ?>" target="_blank">
                                <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                        <?php } ?>
                        <?php if (!empty($smls_logo_type_prefix['logo_tumblr_url'])) { ?>
                            <a class="smls-tumblr-link" href="<?php echo esc_url($smls_logo_type_prefix['logo_tumblr_url']); ?>" target="_blank">
                                <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                            <?php } ?>
                    </div>
                <?php } ?>
            </div>
            <?php
        }
        ?>

    </div>
</div>