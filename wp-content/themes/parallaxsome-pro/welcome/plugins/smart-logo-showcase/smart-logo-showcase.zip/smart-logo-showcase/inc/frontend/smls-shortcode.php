<?php
defined('ABSPATH') or die("No script kiddies please!");
require_once(SMLS_PATH . 'inc/admin/smls-resizer.php');
$post_id = $atts['id'];
$smls_option = get_post_meta($post_id, 'smls_option', true);
$smls_settings = get_post_meta($post_id, 'smls_settings', true);
$random_num = rand(111111111, 999999999);
//$this->print_array( $smls_option );
?>
<div class="smls-main-logo-outer-<?php echo $random_num; ?> smls-main-logo-wrapper <?php
if ($smls_settings['carousel_type'] == 'vertical') {
    echo 'smls-carousel-vertical-wrapper';
}
?>" data-logo-type="<?php
     if (isset($smls_option['smls_logo_type'])) {
         echo esc_attr($smls_option['smls_logo_type']);
     }
     ?>">
         <?php
         if (isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'without_filter') {
             if (isset($smls_settings['logo_layout']) && $smls_settings['logo_layout'] == 'grid') {
                 ?>
            <div class="smls-grid-container-<?php echo esc_attr($smls_settings['grid_layout']); ?> smls-grid smls-grid-column-<?php echo esc_attr($smls_settings['desktop_column']); ?> smls-tablet-column-<?php echo esc_attr($smls_settings['tablet_column']); ?> smls-mobile-column-<?php echo esc_attr($smls_settings['mobile_column']); ?> <?php
            if ($smls_settings['grid_layout'] == "template-1" || $smls_settings['grid_layout'] == "template-2" || $smls_settings['grid_layout'] == "template-3" || $smls_settings['grid_layout'] == "template-4" || $smls_settings['grid_layout'] == "template-5" || $smls_settings['grid_layout'] == "template-6" || $smls_settings['grid_layout'] == "template-8" || $smls_settings['grid_layout'] == "template-9") {

                if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                    ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                     } else {
                         echo ' smls-overlay-effect';
                     }
                 }
                 ?> clearfix
                 ">
                     <?php
                     $image_number = 0;
                     $grid_items = -1;
                     //$total_logo = count($smls_option['logo']);
                     foreach ($smls_option['logo'] as $logo_key => $logo_detail) {
                         $image_number++;
                         $grid_items++;
                         if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                             /*
                              * Popup layout
                              */
                             if (isset($smls_settings['full_view_type']) && $smls_settings['full_view_type'] == 'popup') {
                                 include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                             } //closing for popup
                             /*
                              * Inline layout
                              */ else {
                                 if ($smls_settings['grid_layout'] == 'template-1' || $smls_settings['grid_layout'] == 'template-2' || $smls_settings['grid_layout'] == 'template-3' || $smls_settings['grid_layout'] == 'template-4' || $smls_settings['grid_layout'] == 'template-5' || $smls_settings['grid_layout'] == 'template-6') {
                                     ?>
                                <div class="smls-grid-each-item <?php
                                if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    echo 'smls-tooltip';
                                } if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                    echo ' smls-icon-center';
                                } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                    echo ' smls-overlay-title-center';
                                }
                                ?>"
                                <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    ?>
                                         title="<?php
                                         if (isset($smls_option['logo'][$logo_key]['title'])) {
                                             echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                         }
                                         ?>"  data-id="smls_<?php
                                         echo rand(111111111, 999999999);
                                         ?>"
                                         data-template="<?php
                                         if (isset($smls_settings['tooltip_template'])) {
                                             echo esc_attr($smls_settings['tooltip_template']);
                                         }
                                         ?>"
                                         data-position="<?php
                                         if (isset($smls_settings['tooltip_position'])) {
                                             echo esc_attr($smls_settings['tooltip_position']);
                                         }
                                         ?>"
                                         data-animation="<?php
                                         if (isset($smls_settings['tooltip_animation'])) {
                                             echo esc_attr($smls_settings['tooltip_animation']);
                                         }
                                         ?>"
                                         data-duration="<?php
                                         if (isset($smls_settings['tooltip_duration'])) {
                                             echo esc_attr($smls_settings['tooltip_duration']);
                                         }
                                         ?>"
                                         <?php
                                     }
                                     ?> data-image_count="<?php echo $image_number; ?>" data-desktop_column="<?php
                                     if (isset($smls_settings['desktop_column'])) {
                                         echo esc_attr($smls_settings['desktop_column']);
                                     }
                                     ?>"
                                     data-ipad_column="<?php
                                     if (isset($smls_settings['tablet_column'])) {
                                         echo esc_attr($smls_settings['tablet_column']);
                                     }
                                     ?>"
                                     data-mobile_column="<?php
                                     if (isset($smls_settings['mobile_column'])) {
                                         echo esc_attr($smls_settings['mobile_column']);
                                     }
                                     ?>" data-shortcode_id="<?php echo $post_id; ?>">

                                    <div class="smls-inline-loading" style="display: none;">
                                        <img src="<?php echo SMLS_IMG_DIR . '/loading.gif' ?>">
                                    </div>
                                    <?php if ($smls_settings['logo_image_effects'] == 'overlay') { ?>
                                        <div class="smls-overlay-wrap"></div>
                                    <?php } ?>
                                    <div class="smls-logo-inline-detail">
                                        <?php if ($smls_settings['logo_image_effects'] == 'hover') { ?>
                                            <div class="smls-inline-image-container smls-inline-img-wrap"  data-id="smls_inline_<?php echo rand(10000, 99999); ?>" data-logo-key="<?php echo $logo_key; ?>">
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            </div>
                                            <?php
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                   <?php }
                                                   ?>
                                                <div class="smls-inline-image-container smls-inline-icon" data-id="smls_inline_<?php echo rand(10000, 99999); ?>" data-logo-key="<?php echo $logo_key; ?>">
                                                    <span><i class="fa fa-search" aria-hidden="true"></i></span>
                                                </div>
                                            </div>
                                        <?php }
                                        ?>

                                    </div>
                                </div>
                                <?php
                            }
                        }/*
                         * / closing for full view
                         */
                    } else if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-8') {
                        ?>
                        <div class="smls-logo-rec-wrap <?php
                        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            echo 'smls-tooltip';
                        }

                        if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                            echo ' smls-overlay-title-center';
                        }
                        ?>" <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            ?>
                                 title="<?php
                                 if (isset($smls_option['logo'][$logo_key]['title'])) {
                                     echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                 }
                                 ?>"  data-id="smls_<?php
                                 echo rand(111111111, 999999999);
                                 ?>"
                                 data-template="<?php
                                 if (isset($smls_settings['tooltip_template'])) {
                                     echo esc_attr($smls_settings['tooltip_template']);
                                 }
                                 ?>"
                                 data-position="<?php
                                 if (isset($smls_settings['tooltip_position'])) {
                                     echo esc_attr($smls_settings['tooltip_position']);
                                 }
                                 ?>"
                                 data-animation="<?php
                                 if (isset($smls_settings['tooltip_animation'])) {
                                     echo esc_attr($smls_settings['tooltip_animation']);
                                 }
                                 ?>"
                                 data-duration="<?php
                                 if (isset($smls_settings['tooltip_duration'])) {
                                     echo esc_attr($smls_settings['tooltip_duration']);
                                 }
                                 ?>"
                                 <?php
                             }
                             ?>>
                            <div class="smls-logo-block-container clearfix">
                                <div class="smls-eight-content-wrap">
                                    <div class="smls-block-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <div class="smls-block-content-wrap">
                                        <div class="smls-close-detail" style="display:none;">
                                            <span><i class="fa fa-times" aria-hidden="true"></i>
                                            </span>
                                        </div>
                                        <div class="smls-eight-outer-container">
                                            <div class="smls-pre-content-wrap">
                                                <div class="smls-logo-title">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                    }
                                                    ?>
                                                </div>
                                                <div class="smls-logo-tagline">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['sub_heading'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['sub_heading']);
                                                    }
                                                    ?>
                                                </div>
                                                <div class="smls-hover-social-icons">
                                                    <?php if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                                        ?>
                                                        <div class="smls-hover-icon-wrap">
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                                            <?php } ?>
                                                        </div>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <!--inline toggle-->
                                            <div class="smls-grid-eight-toggle-content" style="display: none;">
                                                <div class="smls-grid-desp" style="height:120px;">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['logo_description']);
                                                    }
                                                    ?>
                                                </div>
                                                <div class="smls-grid-eight-gallery">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['gallery_detail'])) {
                                                        foreach ($smls_option['logo'][$logo_key]['gallery_detail'] as $gallery_key => $detail) {
                                                            ?>
                                                            <a href="<?php
                                                            if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                                                echo esc_url($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                                            }
                                                            ?>" data-smlslightbox="gallery"><img src="<?php
                                                                   if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                                                       echo esc_attr($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                                                   }
                                                                   ?>" width="100" height="100" alt="" /></a>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }//end of template 8
                    else if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-9') {
                        ?>
                        <div class="smls-grid-nine-wapper clearfix <?php
                        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            echo 'smls-tooltip';
                        }
                        ?>" <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            ?>
                                 title="<?php
                                 if (isset($smls_option['logo'][$logo_key]['title'])) {
                                     echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                 }
                                 ?>"  data-id="smls_<?php
                                 echo rand(111111111, 999999999);
                                 ?>"
                                 data-template="<?php
                                 if (isset($smls_settings['tooltip_template'])) {
                                     echo esc_attr($smls_settings['tooltip_template']);
                                 }
                                 ?>"
                                 data-position="<?php
                                 if (isset($smls_settings['tooltip_position'])) {
                                     echo esc_attr($smls_settings['tooltip_position']);
                                 }
                                 ?>"
                                 data-animation="<?php
                                 if (isset($smls_settings['tooltip_animation'])) {
                                     echo esc_attr($smls_settings['tooltip_animation']);
                                 }
                                 ?>"
                                 data-duration="<?php
                                 if (isset($smls_settings['tooltip_duration'])) {
                                     echo esc_attr($smls_settings['tooltip_duration']);
                                 }
                                 ?>"
                                 <?php
                             }
                             ?>>
                            <div class="smls-block-nine-img-wrap">
                                <div class="smls-image-wrap">
                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                </div>
                                <div class="smls-grid-nine-container" style="display: none;">
                                    <div class="smls-close-detail">
                                        <span><i class="fa fa-times" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                    <div class="smls-grid-nine-title">
                                        <?php
                                        if (isset($smls_option['logo'][$logo_key]['title'])) {
                                            echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                        }
                                        ?>
                                    </div>
                                    <div class="smls-grid-desp" style="height:120px;">
                                        <?php
                                        if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                            echo esc_attr($smls_option['logo'][$logo_key]['logo_description']);
                                        }
                                        ?>
                                    </div>
                                    <div class="smls-grid-nine-gallery">
                                        <?php
                                        if (isset($smls_option['logo'][$logo_key]['gallery_detail'])) {
                                            foreach ($smls_option['logo'][$logo_key]['gallery_detail'] as $gallery_key => $detail) {
                                                ?>
                                                <a href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                                }
                                                ?>" data-smlslightbox="gallery"><img src="<?php
                                                       if (isset($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url'])) {
                                                           echo esc_attr($smls_option['logo'][$logo_key]['gallery_detail'][$gallery_key]['logo_gallery_url']);
                                                       }
                                                       ?>" width="100" height="100" alt="" /></a>
                                                    <?php
                                                }
                                            }
                                            ?>
                                    </div>
                                    <div class="smls-social-icons">
                                        <div class="smls-hover-icon-wrap">
                                            <?php if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                                ?>

                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                    <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                        <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                    <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                        <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                    <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                        <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                    <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                        <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                    <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                        <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                    <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                        <i class="fa fa-skype" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                    <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                        <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                    <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                        <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                    <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                        <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                                <?php } ?>

                                                <?php
                                            }
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-style" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                               <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }//end of template 9
                    else if (isset($smls_settings['grid_layout']) && $smls_settings['grid_layout'] == 'template-7') {
                        $image_url = esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                        $crop_img = smls_resize($image_url, 240, 360, 360, null, false);
                        ?><div class="smls-grid-image-wrap <?php
                        if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                            echo ' smls-external-link-wrapper';
                        }
                        ?>">
                            <ul class="clearfix">
                                <li class="smls-logo-box">
                                    <div class="smls-logo-image-container">
                                        <figure>
                                            <img src="<?php echo $image_url; ?>">
                                        </figure>
                                        <div class="smls-logo-info-wrap">
                                            <div class="smls-info-hover-wrap">
                                                <div class="smls-hover-title">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                    }
                                                    ?>
                                                </div>
                                                <div class="smls-hover-description">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['logo_description']);
                                                    }
                                                    ?>
                                                </div>
                                                <div class="smls-hover-social-icons">
                                                    <?php if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                                        ?>
                                                        <div class="smls-hover-icon-wrap">
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                                            <?php } ?>
                                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                                            <?php } ?>
                                                        </div>
                                                        <?php
                                                    }
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                        ?>
                                                        <a class="smls-url-link-style" href="<?php
                                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                            echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                        }
                                                        ?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                                       <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="smls-grid-image-wrap <?php
                        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            echo 'smls-tooltip';
                        } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                            echo ' smls-overlay-title-center';
                        }
                        if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                            echo ' smls-external-link-wrapper';
                        }
                        ?>" <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            ?>
                                 title="<?php
                                 if (isset($smls_option['logo'][$logo_key]['title'])) {
                                     echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                 }
                                 ?>"  data-id="smls_<?php
                                 echo rand(111111111, 999999999);
                                 ?>"
                                 data-template="<?php
                                 if (isset($smls_settings['tooltip_template'])) {
                                     echo esc_attr($smls_settings['tooltip_template']);
                                 }
                                 ?>"
                                 data-position="<?php
                                 if (isset($smls_settings['tooltip_position'])) {
                                     echo esc_attr($smls_settings['tooltip_position']);
                                 }
                                 ?>"
                                 data-animation="<?php
                                 if (isset($smls_settings['tooltip_animation'])) {
                                     echo esc_attr($smls_settings['tooltip_animation']);
                                 }
                                 ?>"
                                 data-duration="<?php
                                 if (isset($smls_settings['tooltip_duration'])) {
                                     echo esc_attr($smls_settings['tooltip_duration']);
                                 }
                                 ?>"
                                 <?php
                             }
                             ?>>
                            <div class="smls-grid-pad-container">
                                <?php
                                if ($smls_settings['logo_image_effects'] == 'hover') {
                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                        ?>
                                        <a class="smls-url-link-only" href="<?php
                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                            echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                        }
                                        ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                           <?php
                                       } else {
                                           ?>
                                        <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                        <?php
                                    }
                                }
                                if ($smls_settings['logo_image_effects'] == 'overlay') {
                                    ?>
                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                    <div class="smls-overlay-all-wrap">
                                        <?php
                                        if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                            if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                ?>
                                                <div class="smls-overlay-title">
                                                    <?php
                                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                    }
                                                    ?>
                                                </div>
                                                <?php
                                            }
                                        }
                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                            ?>
                                            <a class="smls-link-style" href="<?php
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                            }
                                            ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                               <?php
                                           }
                                           ?>
                                    </div>
                                    <div class="smls-overlay-wrap"></div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                }//closing for foreach
                ?>
            </div>
            <?php
        }//closing for grid
        /*
         * list
         */
        if (isset($smls_settings['logo_layout']) && $smls_settings['logo_layout'] == 'list') {
            ?>
            <div class="smls-list-container-<?php echo esc_attr($smls_settings['list_layout']); ?> <?php
            if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                 } else {
                     echo ' smls-overlay-effect';
                 }
                 ?>">
                     <?php
                     foreach ($smls_option['logo'] as $logo_key => $logo_detail) {
                         ?>
                    <div class="smls-list-block clearfix">
                        <div class="smls-close-list-inline" style="display:none;">
                            <span><i class="fa fa-times" aria-hidden="true"></i>
                            </span>
                        </div>
                        <div class="smls-list-image-wrap <?php
                        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            echo 'smls-tooltip';
                        }
                        if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                            echo ' smls-icon-center';
                        } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                            echo ' smls-overlay-title-center';
                        }
                        ?>" <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            ?>
                                 title="<?php
                                 if (isset($smls_option['logo'][$logo_key]['title'])) {
                                     echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                 }
                                 ?>"  data-id="smls_<?php
                                 echo rand(111111111, 999999999);
                                 ?>"
                                 data-template="<?php
                                 if (isset($smls_settings['tooltip_template'])) {
                                     echo esc_attr($smls_settings['tooltip_template']);
                                 }
                                 ?>"
                                 data-position="<?php
                                 if (isset($smls_settings['tooltip_position'])) {
                                     echo esc_attr($smls_settings['tooltip_position']);
                                 }
                                 ?>"
                                 data-animation="<?php
                                 if (isset($smls_settings['tooltip_animation'])) {
                                     echo esc_attr($smls_settings['tooltip_animation']);
                                 }
                                 ?>"
                                 data-duration="<?php
                                 if (isset($smls_settings['tooltip_duration'])) {
                                     echo esc_attr($smls_settings['tooltip_duration']);
                                 }
                                 ?>"
                             <?php }
                             ?>>
                            <div class = "smls-inline-image-wrap">
                                <?php
                                if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                    if (isset($smls_settings['full_view_type']) && $smls_settings['full_view_type'] == 'popup') {

                                        include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                    } //closing for popup
                                    else {
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            ?>
                                            <div class="smls-list-inline-open smls-inline-img-wrap">
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            </div>
                                            <?php
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                   <?php }
                                                   ?>
                                                <div class="smls-inline-icon smls-list-inline-open">
                                                    <span><i class="fa fa-search" aria-hidden="true"></i></span>
                                                </div>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                    }
                                    ?>

                                    <?php
                                } else {

                                    if ($smls_settings['logo_image_effects'] == 'hover') {
                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                            ?>
                                            <a class="smls-url-link-only" href="<?php
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                            }
                                            ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                               <?php
                                           } else {
                                               ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <?php
                                        }
                                    }
                                    if ($smls_settings['logo_image_effects'] == 'overlay') {
                                        ?>
                                        <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                        <div class="smls-overlay-all-wrap">
                                            <?php
                                            if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                    ?>
                                                    <div class="smls-overlay-title">
                                                        <?php
                                                        if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                            echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                        }
                                                        ?>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-link-style" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                   <?php
                                               }
                                               ?>
                                        </div>
                                        <div class="smls-overlay-wrap"></div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <div class="smls-list-detail-wrap">
                            <div class="smls-list-title">
                                <?php
                                if (isset($smls_option['logo'][$logo_key]['title'])) {
                                    echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                }
                                ?>
                            </div>
                            <div class="smls-list-description">
                                <?php
                                if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                    $descp = wp_trim_words($smls_option['logo'][$logo_key]['logo_description'], 60);
                                    echo esc_attr($descp);
                                }
                                ?>
                            </div>
                            <div class="smls-list-icon-wrap">
                                <?php if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                    ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>

                                        <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                            <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                        <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                            <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                        <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                            <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                        <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                            <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                        <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                            <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                        <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                            <i class="fa fa-skype" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                        <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                            <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                        <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                            <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                    <?php } ?>
                                    <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                        <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                            <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                    <?php } ?>

                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                            if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                if (isset($smls_settings['full_view_type']) && $smls_settings['full_view_type'] == 'inline') {
                                    include(SMLS_PATH . 'inc/frontend/smls-detail/smls-list-inline.php');
                                }
                            }
                            ?>
                        </div>
                    </div>
                <?php }
                ?>
            </div>
            <?php
        } //closing of list
        /*
         * perspective
         */
        if (isset($smls_settings['logo_layout']) && $smls_settings['logo_layout'] == 'perspective') {
            ?>
            <div class="smls-perspective smls-perspective-<?php echo esc_attr($smls_settings['perspective_layout']); ?> <?php if ($smls_settings['controls_type'] == 'arrow') { ?> smls-carousel-arrow-<?php
                echo esc_attr($smls_settings['arrow_type']);
            } if ($smls_settings['controls_type'] == 'text') {
                echo 'smls-text-arrow';
            }
            if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                 } else {
                     echo ' smls-overlay-effect';
                 }
                 ?>" data-control-type="<?php
                 if (isset($smls_settings['controls_type'])) {
                     echo esc_attr($smls_settings['controls_type']);
                 }
                 ?>"
                 data-control="<?php
                 if (isset($smls_settings['carousel_controls'])) {
                     echo esc_attr($smls_settings['carousel_controls']);
                 }
                 ?>"
                 data-auto="<?php
                 if (isset($smls_settings['carousel_auto'])) {
                     echo esc_attr($smls_settings['carousel_auto']);
                 }
                 ?>"
                 data-auto-speed="<?php
                 if (isset($smls_settings['smls_auto_speed'])) {
                     echo esc_attr($smls_settings['smls_auto_speed']);
                 }
                 ?>"

                 data-arrow-type="<?php
                 if (isset($smls_settings['arrow_type'])) {
                     echo esc_attr($smls_settings['arrow_type']);
                 }
                 ?>"
                 data-id="smls_filter_<?php
                 echo rand(1111111, 9999999);
                 ?>">
                <ul class="smls-perspctive-item">
                    <?php foreach ($smls_option['logo'] as $logo_key => $logo_detail) { ?>
                        <li class="<?php
                        if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'popup')) {
                            echo ' smls-icon-center';
                        } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'popup' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                            echo ' smls-overlay-title-center';
                        }
                        ?>">
                                <?php
                                if (isset($smls_settings['perspective_layout']) && $smls_settings['perspective_layout'] == 'template-4') {
                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                        ?>
                                    <div class="smls-flip-four-title">
                                        <?php
                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                        ?>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                            <div class="smls-perspective-img-wrap <?php
                            if ($smls_settings['perspective_layout'] == 'template-1' || $smls_settings['perspective_layout'] == 'template-2' || $smls_settings['perspective_layout'] == 'template-4') {

                            }
                            ?>">
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } else {
                                         ?>
                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                    <?php
                                    if ($smls_settings['perspective_layout'] == 'template-1' || $smls_settings['perspective_layout'] == 'template-2' || $smls_settings['perspective_layout'] == 'template-4') {

                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <?php
                            if (isset($smls_settings['perspective_layout']) && $smls_settings['perspective_layout'] == 'template-2') {
                                if (isset($smls_option['logo'][$logo_key]['title'])) {
                                    ?>
                                    <div class="smls-perspective-title-block">
                                        <?php
                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                        ?>
                                    </div>
                                    <?php
                                }
                            }
                            if (isset($smls_settings['perspective_layout']) && $smls_settings['perspective_layout'] == 'template-3') {
                                ?><div class="smls-perspective-content-block">
                                <?php if (isset($smls_option['logo'][$logo_key]['title'])) {
                                    ?>
                                        <div class="smls-perspective-title-block">
                                            <?php
                                            echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                            ?>
                                        </div>
                                        <?php
                                    }

                                    if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                        ?>
                                        <div class="smls-perspective-description">
                                            <?php
                                            $descp = wp_trim_words($smls_option['logo'][$logo_key]['logo_description'], 20);
                                            echo esc_attr($descp);
                                            ?>
                                        </div>

                                    <?php }
                                    ?>
                                    <div class = "smls-list-icon-wrap">
                                        <?php if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                            ?>

                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                            <?php } ?>

                                            <?php
                                        }
                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                            ?>
                                            <a class="smls-url-link-style" href="<?php
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                            }
                                            ?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                        <?php } ?></div>
                                </div>
                            <?php } ?>

                        </li>
                    <?php } ?>
                </ul>

            </div>
            <?php
        }

        /*
         * Carousel
         */
        if (isset($smls_settings['logo_layout']) && $smls_settings['logo_layout'] == 'carousel') {
            if (isset($smls_settings['carousel_type']) && $smls_settings['carousel_type'] == 'horizontal') {
                ?>
                <div class="smls-carousel-logo smls-carousel-<?php echo esc_attr($smls_settings['carousel_layout']); ?> <?php
                if ($smls_settings['carousel_controls'] == 'true') {
                    if ($smls_settings['controls_type'] == 'arrow') {
                        ?> smls-carousel-arrow-<?php
                             echo esc_attr($smls_settings['arrow_type']);
                         } if ($smls_settings['controls_type'] == 'text') {
                             echo 'smls-text-arrow';
                         }
                     } if ($smls_settings['carousel_pager'] == 'true') {
                         ?> smls-carousel-pager-<?php
                         echo esc_attr($smls_settings['pager_template']);
                     }
                     if ($smls_settings['carousel_layout'] == 'template-1' || $smls_settings['carousel_layout'] == 'template-2' || $smls_settings['carousel_layout'] == 'template-3' || $smls_settings['carousel_layout'] == 'template-4' || $smls_settings['carousel_layout'] == 'template-6' || $smls_settings['carousel_layout'] == 'template-8' || $smls_settings['carousel_layout'] == 'template-9' || $smls_settings['carousel_layout'] == 'template-10') {
                         if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                             ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                         } else {
                             echo ' smls-overlay-effect';
                         }
                     }
                     ?>"  data-autoplay="<?php
                     if (isset($smls_settings['carousel_auto'])) {
                         echo esc_attr($smls_settings['carousel_auto']);
                     }
                     ?>"
                     data-id="smls_<?php
                     echo rand(1111111, 9999999);
                     ?>"
                     data-pager="<?php
                     if (isset($smls_settings['carousel_pager'])) {
                         echo esc_attr($smls_settings['carousel_pager']);
                     }
                     ?>" data-controls="<?php
                     if (isset($smls_settings['carousel_controls'])) {
                         echo esc_attr($smls_settings['carousel_controls']);
                     }
                     ?>" data-controls-type="<?php
                     if (isset($smls_settings['controls_type'])) {
                         echo esc_attr($smls_settings['controls_type']);
                     }
                     ?>" data-slide-count="<?php
                     if (isset($smls_settings['smls_slide_count'])) {
                         echo esc_attr($smls_settings['smls_slide_count']);
                     }
                     ?>"
                     data-auto-speed="<?php
                     if (isset($smls_settings['smls_auto_speed'])) {
                         echo esc_attr($smls_settings['smls_auto_speed']);
                     }
                     ?>"
                     data-template="<?php
                     if (isset($smls_settings['carousel_layout'])) {
                         echo esc_attr($smls_settings['carousel_layout']);
                     }
                     ?>" data-pager-template="<?php
                     if (isset($smls_settings['pager_template'])) {
                         echo esc_attr($smls_settings['pager_template']);
                     }
                     ?>"
                     data-arrow-type="<?php
                     if (isset($smls_settings['arrow_type'])) {
                         echo esc_attr($smls_settings['arrow_type']);
                     }
                     ?>">
                         <?php
                         $total_logo = count($smls_option['logo']);
                         $count_item = 0;
                         foreach ($smls_option['logo'] as $logo_key => $logo_detail) {
                             $count_item++;
                             if ($smls_settings['carousel_layout'] == 'template-1') {
                                 ?>
                            <div class="smls-logo-carousel-1 <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } else {
                                         ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class = "smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                <?php } ?>
                            </div>
                        <?php } if ($smls_settings['carousel_layout'] == 'template-2') {
                            ?>
                            <div class="smls-item  <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                <div class="smls-car-two-content-wrap">
                                    <?php if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                        ?>
                                        <div class="smls-carousel-two-title">
                                            <?php echo esc_attr($smls_option['logo'][$logo_key]['title']); ?>
                                        </div>
                                        <?php
                                    }
                                    if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                        ?>
                                        <div class="smls-carousel-two-description">
                                            <?php
                                            $descp = wp_trim_words($smls_option['logo'][$logo_key]['logo_description'], 20);
                                            echo esc_attr($descp);
                                            ?>
                                        </div>
                                        <?php
                                    }

                                    if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                        ?>
                                        <div class="smls-social-icon-wrap">
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                            <?php } ?>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                                <?php
                                if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                    include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                } else {
                                    ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class = "smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        <?php } if ($smls_settings['carousel_layout'] == 'template-3') {
                            ?>
                            <div class="smls-carousel-3-items  <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } else {
                                         ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                        <?php }
                                        ?>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="smls-car-three-content-wrap">
                                    <?php
                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                        ?>
                                        <div class="smls-carousel-two-title">
                                            <?php echo esc_attr($smls_option['logo'][$logo_key]['title']); ?>
                                        </div>
                                        <?php
                                    }
                                    if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                        ?>
                                        <div class="smls-social-icon-wrap clearfix">
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                            <?php } ?>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        if ($smls_settings['carousel_layout'] == 'template-4') {
                            ?>
                            <div class="smls-carousel-four-items  <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } //closing for popup
                                     else {
                                         ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                            ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        } if ($smls_settings['carousel_layout'] == 'template-5' || $smls_settings['carousel_layout'] == 'template-7') {
                            ?>
                            <div class="smls-carousel-five-items <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                     <?php
                                     if ($smls_settings['carousel_layout'] == 'template-7') {
                                         ?>
                                    <div class="smls-car-temp-7-image-wrap">
                                        <?php
                                    }
                                    ?>

                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                    ?>">
                                         <?php
                                         if ($smls_settings['carousel_layout'] == 'template-7') {
                                             ?>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="smls-car-two-content-wrap">
                                    <?php if ($smls_settings['carousel_layout'] == 'template-5') { ?>
                                        <div class="smls-car-five-hover-wrap">
                                        <?php } ?>
                                        <?php
                                        if (isset($smls_option['logo'][$logo_key]['title'])) {
                                            ?>
                                            <div class="smls-carousel-two-title">
                                                <?php echo esc_attr($smls_option['logo'][$logo_key]['title']); ?>
                                            </div>
                                            <?php
                                        }
                                        if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                            $descp = wp_trim_words($smls_option['logo'][$logo_key]['logo_description'], 20);
                                            ?>
                                            <div class="smls-carousel-two-description">
                                                <?php echo esc_attr($descp); ?>
                                            </div>
                                        <?php }
                                        ?>
                                        <div class="smls-social-icon-wrap">
                                            <?php
                                            if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                                ?>

                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                    <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                        <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                    <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                        <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                    <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                        <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                    <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                        <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                    <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                        <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                    <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                        <i class="fa fa-skype" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                    <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                        <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                    <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                        <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                                <?php } ?>
                                                <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                    <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                        <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                                <?php } ?>

                                            <?php }
                                            ?>

                                            <?php
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-style" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                               <?php } ?>
                                        </div>
                                        <?php if ($smls_settings['carousel_layout'] == 'template-5') { ?>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php
                        } if ($smls_settings['carousel_layout'] == 'template-6') {
                            ?>
                            <div class="smls-carousel-five-items <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                     title="<?php
                                     if (isset($smls_option['logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?>>
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } //closing for popup
                                     else {
                                         ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                            ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                <?php }
                                ?>
                                <div class="smls-car-two-content-wrap">

                                    <?php
                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                        ?>
                                        <div class="smls-carousel-two-title">
                                            <?php echo esc_attr($smls_option['logo'][$logo_key]['title']); ?>
                                        </div>
                                        <?php
                                    }
                                    if (isset($smls_option['logo'][$logo_key]['logo_description'])) {
                                        ?>
                                        <div class="smls-carousel-two-description">
                                            <?php
                                            $descp = wp_trim_words($smls_option['logo'][$logo_key]['logo_description'], 26);
                                            echo esc_attr($descp);
                                            ?>
                                        </div>
                                    <?php }
                                    ?>
                                    <div class="smls-social-icon-wrap">
                                        <?php
                                        if (isset($smls_option['logo'][$logo_key]['logo_social_icon']) && $smls_option['logo'][$logo_key]['logo_social_icon'] == 1) {
                                            ?>

                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_facebook_url'])) { ?>
                                                <a class="smls-fb-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_facebook_url']); ?>" target="_blank">
                                                    <i class="fa fa-facebook" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_twitter_url'])) { ?>
                                                <a class="smls-twitter-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_twitter_url']); ?>" target="_blank">
                                                    <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_linkedin_url'])) { ?>
                                                <a class="smls-linkedin-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_linkedin_url']); ?>" target="_blank">
                                                    <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_instagram_url'])) { ?>
                                                <a class="smls-instagram-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_instagram_url']); ?>" target="_blank">
                                                    <i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_gplus_url'])) { ?>
                                                <a class="smls-gplus-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_gplus_url']); ?>" target="_blank">
                                                    <i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_skype_url'])) { ?>
                                                <a class="smls-skype-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_skype_url']); ?>" target="_blank">
                                                    <i class="fa fa-skype" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_youtube_url'])) { ?>
                                                <a class="smls-youtube-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_youtube_url']); ?>" target="_blank">
                                                    <i class="fa fa-youtube" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_pinterest_url'])) { ?>
                                                <a class="smls-pinterest-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_pinterest_url']); ?>" target="_blank">
                                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                            <?php } ?>
                                            <?php if (!empty($smls_option['logo'][$logo_key]['logo_tumblr_url'])) { ?>
                                                <a class="smls-tumblr-link" href="<?php echo esc_url($smls_option['logo'][$logo_key]['logo_tumblr_url']); ?>" target="_blank">
                                                    <i class="fa fa-tumblr" aria-hidden="true"></i></i></a>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        if ($smls_settings['carousel_layout'] == 'template-8' || $smls_settings['carousel_layout'] == 'template-9') {
                            $logo_row = $count_item % 2;
                            ?>
                            <?php if ($logo_row == 1) {
                                ?>
                                <div class="smls-row-wrap">
                                <?php }
                                ?>
                                <div class="smls-row-image  <?php
                                if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    echo 'smls-tooltip';
                                }
                                if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                    echo ' smls-icon-center';
                                } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                    echo ' smls-overlay-title-center';
                                }
                                ?>"
                                <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    ?>
                                         title="<?php
                                         if (isset($smls_option['logo'][$logo_key]['title'])) {
                                             echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                         }
                                         ?>"  data-id="smls_<?php
                                         echo rand(111111111, 999999999);
                                         ?>"
                                         data-template="<?php
                                         if (isset($smls_settings['tooltip_template'])) {
                                             echo esc_attr($smls_settings['tooltip_template']);
                                         }
                                         ?>"
                                         data-position="<?php
                                         if (isset($smls_settings['tooltip_position'])) {
                                             echo esc_attr($smls_settings['tooltip_position']);
                                         }
                                         ?>"
                                         data-animation="<?php
                                         if (isset($smls_settings['tooltip_animation'])) {
                                             echo esc_attr($smls_settings['tooltip_animation']);
                                         }
                                         ?>"
                                         data-duration="<?php
                                         if (isset($smls_settings['tooltip_duration'])) {
                                             echo esc_attr($smls_settings['tooltip_duration']);
                                         }
                                         ?>"
                                         <?php
                                     }
                                     ?>>
                                         <?php
                                         if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                                             include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                         } //closing for popup
                                         else {
                                             ?>
                                        <div class="smls-car-img-wrap">
                                            <?php
                                            if ($smls_settings['logo_image_effects'] == 'hover') {
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-url-link-only" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                       <?php
                                                   } else {
                                                       ?>
                                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                    <?php
                                                }
                                            }

                                            if ($smls_settings['logo_image_effects'] == 'overlay') {
                                                ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                                ?>">
                                                <div class="smls-overlay-all-wrap">
                                                    <?php
                                                    if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                        if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                            ?>

                                                            <div class="smls-overlay-title">
                                                                <?php
                                                                if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                    echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                                }
                                                                ?>
                                                            </div>

                                                            <?php
                                                        }
                                                    }
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                        ?>
                                                        <a class="smls-link-style" href="<?php
                                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                            echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                        }
                                                        ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                           <?php
                                                       }
                                                       ?>
                                                </div>
                                                <div class="smls-overlay-wrap"></div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php if ($logo_row == 0) { ?>
                                </div>
                                <?php
                            }
                        }
                        if ($smls_settings['carousel_layout'] == 'template-10') {
                            $logo_row = $count_item % 3;
                            ?>
                            <?php if ($logo_row == 1) {
                                ?>
                                <div class="smls-single-wrap">
                                <?php }
                                ?>
                                <div class="smls-single-image  <?php
                                if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    echo 'smls-tooltip';
                                }
                                if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                    echo ' smls-icon-center';
                                } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                    echo ' smls-overlay-title-center';
                                }
                                ?>"
                                <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                    ?>
                                         title="<?php
                                         if (isset($smls_option['logo'][$logo_key]['title'])) {
                                             echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                         }
                                         ?>"  data-id="smls_<?php
                                         echo rand(111111111, 999999999);
                                         ?>"
                                         data-template="<?php
                                         if (isset($smls_settings['tooltip_template'])) {
                                             echo esc_attr($smls_settings['tooltip_template']);
                                         }
                                         ?>"
                                         data-position="<?php
                                         if (isset($smls_settings['tooltip_position'])) {
                                             echo esc_attr($smls_settings['tooltip_position']);
                                         }
                                         ?>"
                                         data-animation="<?php
                                         if (isset($smls_settings['tooltip_animation'])) {
                                             echo esc_attr($smls_settings['tooltip_animation']);
                                         }
                                         ?>"
                                         data-duration="<?php
                                         if (isset($smls_settings['tooltip_duration'])) {
                                             echo esc_attr($smls_settings['tooltip_duration']);
                                         }
                                         ?>"
                                         <?php
                                     }
                                     ?>>
                                         <?php
                                         if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                                             include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                         } //closing for popup
                                         else {
                                             ?>
                                        <div class="smls-car-img-wrap">
                                            <?php
                                            if ($smls_settings['logo_image_effects'] == 'hover') {
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-url-link-only" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                       <?php
                                                   } else {
                                                       ?>
                                                    <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                    <?php
                                                }
                                            }
                                            if ($smls_settings['logo_image_effects'] == 'overlay') {
                                                ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                                ?>">
                                                <div class="smls-overlay-all-wrap">
                                                    <?php
                                                    if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                        if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                            ?>
                                                            <div class="smls-overlay-title">
                                                                <?php
                                                                if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                    echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                                }
                                                                ?>
                                                            </div>
                                                            <?php
                                                        }
                                                    }
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                        ?>
                                                        <a class="smls-link-style" href="<?php
                                                        if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                            echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                        }
                                                        ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                           <?php
                                                       }
                                                       ?>
                                                </div>
                                                <div class="smls-overlay-wrap"></div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php if ($logo_row == 0) { ?>
                                </div>

                            <?php } ?>

                            <?php
                        }
                    }
                    ?>
                </div>
                <?php
            }//closing of horizontal
            else {
                ?>
                <div class="smls-vertical-main-container <?php if ($smls_settings['carousel_pager'] == 'true') {
                    ?> smls-bx-pager-<?php
                         echo esc_attr($smls_settings['pager_template']);
                     }
                     if ($smls_settings['controls_type'] == 'arrow') {
                         ?> smls-carousel-arrow-<?php
                         echo esc_attr($smls_settings['arrow_type']);
                     }
                     if ($smls_settings['controls_type'] == 'text') {
                         echo ' smls-text-arrow';
                     }

                     if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                         ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                     } else {
                         echo ' smls-overlay-effect';
                     }
                     ?>">
                    <ul class="smls-vertical-carousel" data-autoplay="<?php
                    if (isset($smls_settings['carousel_auto'])) {
                        echo esc_attr($smls_settings['carousel_auto']);
                    }
                    ?>"
                        data-id="smls_<?php
                        echo rand(1111111, 9999999);
                        ?>"
                        data-pager="<?php
                        if (isset($smls_settings['carousel_pager'])) {
                            echo esc_attr($smls_settings['carousel_pager']);
                        }
                        ?>" data-controls="<?php
                        if (isset($smls_settings['carousel_controls'])) {
                            echo esc_attr($smls_settings['carousel_controls']);
                        }
                        ?>" data-controls-type="<?php
                        if (isset($smls_settings['controls_type'])) {
                            echo esc_attr($smls_settings['controls_type']);
                        }
                        ?>" data-slide-count="<?php
                        if (isset($smls_settings['smls_slide_count'])) {
                            echo esc_attr($smls_settings['smls_slide_count']);
                        }
                        ?>"
                        data-auto-speed="<?php
                        if (isset($smls_settings['smls_auto_speed'])) {
                            echo esc_attr($smls_settings['smls_auto_speed']);
                        }
                        ?>"
                        data-template="<?php
                        if (isset($smls_settings['carousel_layout'])) {
                            echo esc_attr($smls_settings['carousel_layout']);
                        }
                        ?>"
                        data-arrow-type="<?php
                        if (isset($smls_settings['arrow_type'])) {
                            echo esc_attr($smls_settings['arrow_type']);
                        }
                        ?>"
                        data-pager-template="<?php
                        if (isset($smls_settings['pager_template'])) {
                            echo esc_attr($smls_settings['pager_template']);
                        }
                        ?>" >
                            <?php
                            $count = 0;
                            foreach ($smls_option['logo'] as $logo_key => $logo_detail) {
                                ?>
                            <li class="<?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'inline')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'inline' || $smls_option['logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>"
                            <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                ?>
                                    title="<?php
                                    if (isset($smls_option['logo'][$logo_key]['title'])) {
                                        echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                    }
                                    ?>"  data-id="smls_<?php
                                    echo rand(111111111, 999999999);
                                    ?>"
                                    data-template="<?php
                                    if (isset($smls_settings['tooltip_template'])) {
                                        echo esc_attr($smls_settings['tooltip_template']);
                                    }
                                    ?>"
                                    data-position="<?php
                                    if (isset($smls_settings['tooltip_position'])) {
                                        echo esc_attr($smls_settings['tooltip_position']);
                                    }
                                    ?>"
                                    data-animation="<?php
                                    if (isset($smls_settings['tooltip_animation'])) {
                                        echo esc_attr($smls_settings['tooltip_animation']);
                                    }
                                    ?>"
                                    data-duration="<?php
                                    if (isset($smls_settings['tooltip_duration'])) {
                                        echo esc_attr($smls_settings['tooltip_duration']);
                                    }
                                    ?>"
                                    <?php
                                }
                                ?>>
                                    <?php
                                    if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {

                                        include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                    } //closing for popup
                                    else {
                                        ?>

                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>"></a>
                                                   <?php
                                               } else {
                                                   ?>
                                                <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']); ?>">
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img src="<?php echo esc_attr($smls_option['logo'][$logo_key]['logo_image_url']);
                                            ?>">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo'][$logo_key]['logo_external_link']) && $smls_option['logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                       <?php
                                                   }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
                <?php
            }
        }//closing of carousel
    }//closing for without filter
    if (isset($smls_option['smls_logo_type']) && $smls_option['smls_logo_type'] == 'with_filter') {
        if (isset($smls_settings['filter_type']) && $smls_settings['filter_type'] == 'normal') {
            ?>
            <ul class="smls-filter <?php if (isset($smls_settings['filter_tab_template'])) { ?> smls-tab-<?php
                echo esc_attr($smls_settings['filter_tab_template']);
            }
            ?> clearfix" id="smls_filter_<?php echo $random_num; ?>">
                <li class="active" data-filter="all"><?php _e('All', SMLS_TD); ?></li>
                <?php
                $count = 0;
                foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) {
                    $count++;
                    ?>
                    <li data-filter="<?php echo $count; ?>"><?php
                        if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                            echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                        }
                        ?></li>
                <?php } ?>
            </ul>
            <div class="smls-filtr-container <?php if (isset($smls_settings['filter_template'])) { ?> smls-filter-<?php
                echo esc_attr($smls_settings['filter_template']);
            } if ($smls_settings['filter_layout'] == 'sameSize' && $smls_settings['filter_same_size_template'] == 'template-2') {
                echo 'smls-filter-border-wrap';
            }
            if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                 } else {
                     echo ' smls-overlay-effect';
                 }
                 ?>" id="smls_container_<?php echo $random_num; ?>" data-id="<?php echo $random_num; ?>" data-layout="<?php
                 if (isset($smls_settings['filter_layout'])) {
                     echo esc_attr($smls_settings['filter_layout']);
                 }
                 ?>" data-duration="<?php
                 if (isset($smls_settings['animation_duration'])) {
                     echo esc_attr($smls_settings['animation_duration']);
                 }
                 ?>" data-delaymode="<?php
                 if (isset($smls_settings['delay_mode'])) {
                     echo esc_attr($smls_settings['delay_mode']);
                 }
                 ?>" data-delay="<?php
                 if (isset($smls_settings['delay'])) {
                     echo esc_attr($smls_settings['delay']);
                 }
                 ?>">
                     <?php
                     $count = 0;
                     $image_count = 0;
                     foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) {
                         $count++;
                         ?>
                         <?php
                         if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'])) {
                             foreach ($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'] as $logo_key => $logo_detail) {
                                 $image_id = $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_id'];
                                 $image_attributes = wp_get_attachment_image_src($image_id, 'full');
                                 $image_url = esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']);
                                 $image_width = esc_attr($smls_settings['smls_same_width']);
                                 $image_height = esc_attr($smls_settings['smls_same_height']);
                                 if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'sameWidth') {

                                     $crop_image = smls_resize($image_url, $image_width, $image_attributes[2], $image_attributes[2], null, false);
                                     $image=$crop_image[0];
                                 } else if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'sameHeight') {
                                     $crop_image = smls_resize($image_url, $image_attributes[1], $image_height, $image_height, null, false);
                                      $image=$crop_image[0];
                                 }  else {
                                     $image = $image_url;
                                 }
                                 $image_count++;
                                 ?>
                            <div class="smls-filtr-item <?php
                            if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'packed' || $smls_settings['filter_layout'] == 'sameHeight' || $smls_settings['filter_layout'] == 'sameWidth') {
                                echo 'smls-filter-masonry';
                            }
                            ?>  <?php
                            if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                echo 'smls-tooltip';
                            }
                            if ($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'popup')) {
                                echo ' smls-icon-center';
                            } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'popup' || $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1)) {
                                echo ' smls-overlay-title-center';
                            }
                            ?>" <?php if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'sameSize') {
                                ?> style="width:<?php echo $image_width; ?>px; height:<?php echo $image_height; ?>px;"
                                     <?php
                                 }
                                 if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'sameWidth') {
                                     ?> style="width:<?php echo $image_width; ?>px; height:<?php echo $image_attributes[2]; ?>px;"
                                     <?php
                                 }
                                 if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'sameHeight') {
                                     ?> style="width:<?php echo $image_attributes[1]; ?>px; height:<?php echo $image_height; ?>px;"
                                     <?php
                                 }
                                 if (isset($smls_settings['filter_layout']) && $smls_settings['filter_layout'] == 'packed') {
                                     ?> style="width:<?php echo $image_attributes[1]; ?>px; height:<?php echo $image_attributes[2]; ?>px;"
                                 <?php }
                                 ?>


                                 <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                                     ?>
                                     title="<?php
                                     if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                         echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title']);
                                     }
                                     ?>"  data-id="smls_<?php
                                     echo rand(111111111, 999999999);
                                     ?>"
                                     data-template="<?php
                                     if (isset($smls_settings['tooltip_template'])) {
                                         echo esc_attr($smls_settings['tooltip_template']);
                                     }
                                     ?>"
                                     data-position="<?php
                                     if (isset($smls_settings['tooltip_position'])) {
                                         echo esc_attr($smls_settings['tooltip_position']);
                                     }
                                     ?>"
                                     data-animation="<?php
                                     if (isset($smls_settings['tooltip_animation'])) {
                                         echo esc_attr($smls_settings['tooltip_animation']);
                                     }
                                     ?>"
                                     data-duration="<?php
                                     if (isset($smls_settings['tooltip_duration'])) {
                                         echo esc_attr($smls_settings['tooltip_duration']);
                                     }
                                     ?>"
                                     <?php
                                 }
                                 ?> data-category="<?php echo $count; ?>" data-image_count="<?php echo $image_count; ?>" data-sort="<?php
                                 if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                                     echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                                 }
                                 ?>">
                                     <?php
                                     if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {


                                         include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                     } else {
                                         ?>
                                    <div class="smls-car-img-wrap">
                                        <?php
                                        if ($smls_settings['logo_image_effects'] == 'hover') {
                                            if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link']) && $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-url-link-only" href="<?php
                                                if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank">
                                                    <div class="smls-fil-img-wrap">
                                                        <img class="img-responsive" src="<?php echo $image; ?>" alt="">
                                                    </div>
                                                </a>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="smls-fil-img-wrap">
                                                    <img class="img-responsive" src="<?php echo $image; ?>" alt="">
                                                </div>
                                                <?php
                                            }
                                        }
                                        if ($smls_settings['logo_image_effects'] == 'overlay') {
                                            ?>
                                            <img class="img-responsive" src="<?php echo $image; ?>" alt="">
                                            <div class="smls-overlay-all-wrap">
                                                <?php
                                                if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                    if (!empty($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                                        ?>
                                                        <div class="smls-overlay-title">
                                                            <?php
                                                            if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                                                echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title']);
                                                            }
                                                            ?>
                                                        </div>

                                                        <?php
                                                    }
                                                }
                                                if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link']) && $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1) {
                                                    ?>
                                                    <a class="smls-link-style" href="<?php
                                                    if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'])) {
                                                        echo esc_url($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_url']);
                                                    }
                                                    ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                   <?php }
                                                   ?>
                                            </div>
                                            <div class="smls-overlay-wrap"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        }
                    }
                }
                ?>
            </div>
            <?php
        } else {
            ?>
            <ul class="smls-filter-blur <?php if (isset($smls_settings['filter_tab_template'])) { ?> smls-tab-<?php
                echo $smls_settings['filter_tab_template'];
            }
            ?> clearfix">
                <li class="smls-each-blur-item smls-current"><a href="#"><?php _e('All', SMLS_TD); ?></a></li>
                <?php foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) { ?>
                    <li class="smls-each-blur-item"><a href="#"><?php
                            if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                                echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                            }
                            ?></a></li>
                <?php } ?>
            </ul>
            <div class="smls-thumbnails <?php
            if (isset($smls_settings['logo_image_effects']) && $smls_settings['logo_image_effects'] == 'hover') {
                ?> smls-hover-<?php echo esc_attr($smls_settings['hover_type']); ?><?php
                 } else {
                     echo ' smls-overlay-effect';
                 }
                 ?>">
                     <?php
                     foreach ($smls_option['logo']['filter_detail'] as $filter_key => $detail) {
                         foreach ($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'] as $logo_key => $logo_detail) {
                             ?>
                        <div class="smls-tumb <?php
                        if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_name'])) {
                            echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_name']);
                        }
                        ?>  <?php
                        if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            echo 'smls-tooltip';
                        }
                        if ($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1 && ($smls_settings['full_view_type'] == 'popup')) {
                            echo ' smls-icon-center';
                        } if ($smls_settings['logo_title_view'] == 'title_overlay' && ($smls_settings['full_view_type'] == 'popup' || $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1)) {
                            echo ' smls-overlay-title-center';
                        }
                        ?>"
                        <?php if (isset($smls_settings['logo_title_view']) && $smls_settings['logo_title_view'] == 'title_tooltip') {
                            ?>
                                 title="<?php
                                 if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                     echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title']);
                                 }
                                 ?>"  data-id="smls_<?php
                                 echo rand(111111111, 999999999);
                                 ?>"
                                 data-template="<?php
                                 if (isset($smls_settings['tooltip_template'])) {
                                     echo esc_attr($smls_settings['tooltip_template']);
                                 }
                                 ?>"
                                 data-position="<?php
                                 if (isset($smls_settings['tooltip_position'])) {
                                     echo esc_attr($smls_settings['tooltip_position']);
                                 }
                                 ?>"
                                 data-animation="<?php
                                 if (isset($smls_settings['tooltip_animation'])) {
                                     echo esc_attr($smls_settings['tooltip_animation']);
                                 }
                                 ?>"
                                 data-duration="<?php
                                 if (isset($smls_settings['tooltip_duration'])) {
                                     echo esc_attr($smls_settings['tooltip_duration']);
                                 }
                                 ?>"
                                 <?php
                             }
                             ?>>
                                 <?php
                                 if (isset($smls_settings['smls_show_full_view']) && $smls_settings['smls_show_full_view'] == 1) {
                                     include(SMLS_PATH . 'inc/frontend/smls-detail/smls-popup-layout.php');
                                 } else {
                                     ?>
                                <div class="smls-car-img-wrap">
                                    <?php
                                    if ($smls_settings['logo_image_effects'] == 'hover') {
                                        if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link']) && $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1) {
                                            ?>
                                            <a class="smls-url-link-only" href="<?php
                                            if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'])) {
                                                echo esc_url($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_url']);
                                            }
                                            ?>" target="_blank"><img data-src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" alt=""></a>
                                               <?php
                                           } else {
                                               ?>
                                            <img data-src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" alt="">
                                            <?php
                                        }
                                    }
                                    if ($smls_settings['logo_image_effects'] == 'overlay') {
                                        ?>
                                        <img data-src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" src="<?php echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_image_url']); ?>" alt="">
                                        <div class="smls-overlay-all-wrap">
                                            <?php
                                            if ($smls_settings['logo_title_view'] == 'title_overlay') {
                                                if (!empty($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                                    ?>
                                                    <div class="smls-overlay-title">
                                                        <?php
                                                        if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title'])) {
                                                            echo esc_attr($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['title']);
                                                        }
                                                        ?>
                                                    </div>

                                                    <?php
                                                }
                                            }
                                            if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link']) && $smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'] == 1) {
                                                ?>
                                                <a class="smls-link-style" href="<?php
                                                if (isset($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_link'])) {
                                                    echo esc_url($smls_option['logo']['filter_detail'][$filter_key]['filter_logo'][$logo_key]['logo_external_url']);
                                                }
                                                ?>" target="_blank"><span><i class="fa fa-link" aria-hidden="true"></i></span></a>
                                                   <?php
                                               }
                                               ?>
                                        </div>
                                        <div class="smls-overlay-wrap"></div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <?php
        }
    }
    ?>
</div>
<?php
include(SMLS_PATH . 'inc/frontend/smls-detail/smls-inline-style.php');



