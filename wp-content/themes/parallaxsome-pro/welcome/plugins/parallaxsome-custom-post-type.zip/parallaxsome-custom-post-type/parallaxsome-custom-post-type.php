<?php
/**
 * Plugin Name: Parallaxsome Custom Post Types
 * Plugin URI: http://demo.accesspressthemes.com/parallaxsome-pro/
 * Description: The Plugin Creates a custom post types for blogs and teams.
 * Author: AccessPress Themes
 * Author URI:  http://accesspressthemes.com/
 * Version: 1.0.0
 * Text Domain: parallaxsome-custom-post-type
 * License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

defined( 'ABSPATH' ) or die( "No script kiddies please!" );

/** Registering Post Type for Team **/
function parallaxsome_register_post_types(){
    $labels = array(
        'name'               => esc_html_x( 'Team Member', 'post type general name', 'parallaxsome-custom-post-type' ),
        'singular_name'      => esc_html_x( 'Team Member', 'post type singular name', 'parallaxsome-custom-post-type' ),
        'menu_name'          => esc_html_x( 'Team', 'admin menu', 'parallaxsome-custom-post-type' ),
        'name_admin_bar'     => esc_html_x( 'Team Member', 'add new on admin bar', 'parallaxsome-custom-post-type' ),
        'add_new'            => esc_html_x( 'Add New', 'Team Member', 'parallaxsome-custom-post-type' ),
        'add_new_item'       => esc_html__( 'Add New Team Member', 'parallaxsome-custom-post-type' ),
        'new_item'           => esc_html__( 'New Team Member', 'parallaxsome-custom-post-type' ),
        'edit_item'          => esc_html__( 'Edit Team Member', 'parallaxsome-custom-post-type' ),
        'view_item'          => esc_html__( 'View Team Member', 'parallaxsome-custom-post-type' ),
        'all_items'          => esc_html__( 'All Team Member', 'parallaxsome-custom-post-type' ),
        'search_items'       => esc_html__( 'Search Team Member', 'parallaxsome-custom-post-type' ),
        'parent_item_colon'  => esc_html__( 'Parent Team Member:', 'parallaxsome-custom-post-type' ),
        'not_found'          => esc_html__( 'No Team Member found.', 'parallaxsome-custom-post-type' ),
        'not_found_in_trash' => esc_html__( 'No Team Member found in Trash.', 'parallaxsome-custom-post-type' )
    );

    $args = array(
        'labels'             => $labels,
        'description'        => esc_html__( 'Team Member Detail', 'parallaxsome-custom-post-type' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail' )
    );

    register_post_type( 'team-members', $args );

    $labels = array(
        'name'               => esc_html_x( 'Blogs', 'post type general name', 'parallaxsome-custom-post-type' ),
        'singular_name'      => esc_html_x( 'Blog', 'post type singular name', 'parallaxsome-custom-post-type' ),
        'menu_name'          => esc_html_x( 'Blog', 'admin menu', 'parallaxsome-custom-post-type' ),
        'name_admin_bar'     => esc_html_x( 'Blog', 'add new on admin bar', 'parallaxsome-custom-post-type' ),
        'add_new'            => esc_html_x( 'Add New', 'Blog', 'parallaxsome-custom-post-type' ),
        'add_new_item'       => esc_html__( 'Add New Blog', 'parallaxsome-custom-post-type' ),
        'new_item'           => esc_html__( 'New Blog', 'parallaxsome-custom-post-type' ),
        'edit_item'          => esc_html__( 'Edit Blog', 'parallaxsome-custom-post-type' ),
        'view_item'          => esc_html__( 'View Blog', 'parallaxsome-custom-post-type' ),
        'all_items'          => esc_html__( 'All Blog', 'parallaxsome-custom-post-type' ),
        'search_items'       => esc_html__( 'Search Blog', 'parallaxsome-custom-post-type' ),
        'parent_item_colon'  => esc_html__( 'Parent Blog:', 'parallaxsome-custom-post-type' ),
        'not_found'          => esc_html__( 'No Blog found.', 'parallaxsome-custom-post-type' ),
        'not_found_in_trash' => esc_html__( 'No Blog found in Trash.', 'parallaxsome-custom-post-type' )
    );

    $args = array(
        'labels'             => $labels,
        'description'        => esc_html__( 'Blog Detail', 'parallaxsome-custom-post-type' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'revision', 'comments' )
    );

    register_post_type( 'blog', $args );

    $labels = array(
        'name'              => esc_html__( 'Blog Categories', 'parallaxsome-custom-post-type' ),
        'singular_name'     => esc_html__( 'Blogs Category', 'parallaxsome-custom-post-type' ),
        'search_items'      => esc_html__( 'Search Blog Categories', 'parallaxsome-custom-post-type' ),
        'all_items'         => esc_html__( 'All Blog Categories', 'parallaxsome-custom-post-type' ),
        'parent_item'       => esc_html__( 'Parent Blog Category', 'parallaxsome-custom-post-type' ),
        'parent_item_colon' => esc_html__( 'Parent Blog Category:', 'parallaxsome-custom-post-type' ),
        'edit_item'         => esc_html__( 'Edit Blogs Category', 'parallaxsome-custom-post-type' ),
        'update_item'       => esc_html__( 'Update Blogs Category', 'parallaxsome-custom-post-type' ),
        'add_new_item'      => esc_html__( 'Add New Blogs Category', 'parallaxsome-custom-post-type' ),
        'new_item_name'     => esc_html__( 'New Blogs Category', 'parallaxsome-custom-post-type' ),
        'menu_name'         => esc_html__( 'Blogs Categories', 'parallaxsome-custom-post-type' ),
        
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,   
    );
    register_taxonomy( 'blog-category', 'blog', $args );
}

 add_action('init','parallaxsome_register_post_types');

/**
 * Create a metabox to added some custom filed in posts.
 *
 * @package AccessPress Themes
 * @subpackage ParallaxSome
 * @since 1.0.0
 */

 add_action( 'add_meta_boxes', 'parallaxsome_meta_options' );
 
 if( ! function_exists( 'parallaxsome_meta_options' ) ):
 function  parallaxsome_meta_options() {
    add_meta_box(
        'parallaxsome_team_fields',
        'Team Member Fields',
        'parallaxsome_team_field_callback',
        'team-members',
        'normal',
        'high'
    );
    add_meta_box(
        'parallaxsome_blog_fields',
        'Blogs Fields',
        'parallaxsome_blog_fields_callback',
        'blog',
        'normal',
        'high'
    );
 }
 endif;

function parallaxsome_team_field_callback(){
    global $post;
    wp_nonce_field( basename( __FILE__ ), 'parallaxsome_team_fields' );
    ?>
    <table>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Designation','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_designation" type="text"  value="<?php echo esc_attr(get_post_meta( $post->ID, 'parallaxsome_member_designation', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Email','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_email" type="text"  value="<?php echo esc_attr(get_post_meta( $post->ID, 'parallaxsome_member_email', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right: 30px;"><?php esc_html_e('Member Contact','parallaxsome-custom-post-type'); ?></td>
            <td> <input style="width: 400px;" name="parallaxsome_member_contact" type="text" value="<?php echo esc_attr(get_post_meta($post->ID,'parallaxsome_member_contact',true)); ?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Facebook Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_facebook_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_facebook_profile', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Twitter Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_twitter_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_twitter_profile', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Youtube Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_youtube_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_youtube_profile', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member LinkedIn Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_linkedin_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_linkedin_profile', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Instagram Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_instagram_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_instagram_profile', true ));?>" /></td>
        </tr>
        <tr>
            <td style="padding-right:30px"><?php esc_html_e('Member Google Plus Link','parallaxsome-custom-post-type'); ?></td>
            <td><input style="width:400px;" name="parallaxsome_member_google_profile" type="text"  value="<?php echo esc_url(get_post_meta( $post->ID, 'parallaxsome_member_google_profile', true ));?>" /></td>
        </tr>
    </table>
    <?php
}

function parallaxsome_team_field_save($post_id){
    global $post; 

    // Verify the nonce before proceeding.
    if ( !isset( $_POST[ 'parallaxsome_team_fields' ] ) || !wp_verify_nonce( $_POST[ 'parallaxsome_team_fields' ], basename( __FILE__ ) ) )
        return;

    // Stop WP from clearing custom fields on autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE)
        return;

    
    $old_parallaxsome_member_designation = get_post_meta( $post_id, 'parallaxsome_member_designation', true); 
    $new_parallaxsome_member_designation = sanitize_text_field($_POST['parallaxsome_member_designation']);
    
    $old_parallaxsome_member_email = get_post_meta( $post_id, 'parallaxsome_member_email', true); 
    $new_parallaxsome_member_email = sanitize_text_field($_POST['parallaxsome_member_email']);
    
    $old_parallaxsome_member_contact = get_post_meta( $post_id, 'parallaxsome_member_contact', true); 
    $new_parallaxsome_member_contact = sanitize_text_field($_POST['parallaxsome_member_contact']);
    
    $old_parallaxsome_member_facebook_profile = get_post_meta( $post_id, 'parallaxsome_member_facebook_profile', true); 
    $new_parallaxsome_member_facebook_profile = esc_url_raw($_POST['parallaxsome_member_facebook_profile']);
    
    $old_parallaxsome_member_twitter_profile = get_post_meta( $post_id, 'parallaxsome_member_twitter_profile', true); 
    $new_parallaxsome_member_twitter_profile = esc_url_raw($_POST['parallaxsome_member_twitter_profile']);
    
    $old_parallaxsome_member_youtube_profile = get_post_meta( $post_id, 'parallaxsome_member_youtube_profile', true); 
    $new_parallaxsome_member_youtube_profile = esc_url_raw($_POST['parallaxsome_member_youtube_profile']);
    
    $old_parallaxsome_member_linkedin_profile = get_post_meta( $post_id, 'parallaxsome_member_linkedin_profile', true); 
    $new_parallaxsome_member_linkedin_profile = esc_url_raw($_POST['parallaxsome_member_linkedin_profile']);
    
    $old_parallaxsome_member_instagram_profile = get_post_meta( $post_id, 'parallaxsome_member_instagram_profile', true); 
    $new_parallaxsome_member_instagram_profile = esc_url_raw($_POST['parallaxsome_member_instagram_profile']);
    
    $old_parallaxsome_member_google_profile = get_post_meta( $post_id, 'parallaxsome_member_google_profile', true); 
    $new_parallaxsome_member_google_profile = esc_url_raw($_POST['parallaxsome_member_google_profile']);
    
    if ($new_parallaxsome_member_designation && $new_parallaxsome_member_designation != $old_parallaxsome_member_designation) {
            update_post_meta($post_id, 'parallaxsome_member_designation', $new_parallaxsome_member_designation);  
    }
    if ($new_parallaxsome_member_email && $new_parallaxsome_member_email != $old_parallaxsome_member_email) {
            update_post_meta($post_id, 'parallaxsome_member_email', $new_parallaxsome_member_email);  
    }
    if ($new_parallaxsome_member_contact && $new_parallaxsome_member_contact != $old_parallaxsome_member_contact) {
            update_post_meta($post_id, 'parallaxsome_member_contact', $new_parallaxsome_member_contact);  
    }
    if ($new_parallaxsome_member_facebook_profile && $new_parallaxsome_member_facebook_profile != $old_parallaxsome_member_facebook_profile) {
            update_post_meta($post_id, 'parallaxsome_member_facebook_profile', $new_parallaxsome_member_facebook_profile);  
    }
    if ($new_parallaxsome_member_twitter_profile && $new_parallaxsome_member_twitter_profile != $old_parallaxsome_member_twitter_profile) {
            update_post_meta($post_id, 'parallaxsome_member_twitter_profile', $new_parallaxsome_member_twitter_profile);  
    }
    if ($new_parallaxsome_member_instagram_profile && $new_parallaxsome_member_instagram_profile != $old_parallaxsome_member_instagram_profile) {
            update_post_meta($post_id, 'parallaxsome_member_instagram_profile', $new_parallaxsome_member_instagram_profile);  
    } 
    if ($new_parallaxsome_member_youtube_profile && $new_parallaxsome_member_youtube_profile != $old_parallaxsome_member_youtube_profile) {
            update_post_meta($post_id, 'parallaxsome_member_youtube_profile', $new_parallaxsome_member_youtube_profile);  
    }
     if ($new_parallaxsome_member_linkedin_profile && $new_parallaxsome_member_linkedin_profile != $old_parallaxsome_member_linkedin_profile) {
            update_post_meta($post_id, 'parallaxsome_member_linkedin_profile', $new_parallaxsome_member_linkedin_profile);  
    }
     if ($new_parallaxsome_member_google_profile && $new_parallaxsome_member_google_profile != $old_parallaxsome_member_google_profile) {
            update_post_meta($post_id, 'parallaxsome_member_google_profile', $new_parallaxsome_member_google_profile);  
    }
}
add_action('save_post','parallaxsome_team_field_save');


function parallaxsome_blog_fields_callback(){
   global $post;
   wp_nonce_field( basename( __FILE__ ), 'parallaxsome_post_gallery_nonce' );
   $parallaxsome_post_images = get_post_meta($post->ID, 'post_images', true);
   $parallaxsome_post_images_count = get_post_meta( $post->ID, 'image_count', true );
    ?>
    <table>
        <tr class="gallery-fields">
            <td style="padding-right:30px"><?php esc_html_e( 'Gallery Image', 'parallaxsome-custom-post-type' ); ?></td>
            <td>
                            
            <div class="post-embedgallery-wrapper">
               <div class="post_image_section apmag-not-home">
                   <?php
                       $total_img = 0;
                       if( !empty( $parallaxsome_post_images ) ){                                            
                           $total_img = count( $parallaxsome_post_images );
                           $img_counter = 0;
                           foreach( $parallaxsome_post_images as $gallery_image ){
                              $attachment_id = parallaxsome_attachment_id_by_url( $gallery_image );
                              $img_url = wp_get_attachment_image_src( $attachment_id, 'thumbnail' );                    
                   ?>
                               <div class="gal-img-block">
                                   <div class="gal-img"><img src="<?php echo esc_url($img_url[0]); ?>" /><span class="fig-remove"><?php esc_html_e( 'Remove', 'parallaxsome-custom-post-type' ); ?></span></div>
                                   <input type="hidden" name="post_images[<?php echo absint($img_counter); ?>]" class="hidden-media-gallery" value="<?php echo esc_attr($gallery_image); ?>" />
                               </div>
                   <?php
                               $img_counter++;
                           }
                       }
                   ?>                  
               </div><!-- .post_image_section -->
               <input id="post_image_count" type="hidden" name="image_count" value="<?php echo absint($total_img); ?>">
               <a href="javascript:void(0)" class="docopy-post_image button"><?php esc_html_e( 'Add Image', 'parallaxsome-custom-post-type' );?></a>
           </div><!-- .post-embedgallery-wrapper -->
                  
           </td>       
        </tr>
   </table>
<?php
}

function parallaxsome_save_post_image( $post_id ) {
    global  $post;

    // Verify the nonce before proceeding.
    if ( !isset( $_POST[ 'parallaxsome_post_gallery_nonce' ] ) || !wp_verify_nonce( $_POST[ 'parallaxsome_post_gallery_nonce' ], basename( __FILE__ ) ) )
       return;

    // Stop WP from clearing custom fields on autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE)  
       return;
       

    $image_count = get_post_meta($post->ID, 'image_count', true);
    //Execute this saving function
    $stz_image_count = sanitize_text_field($_POST['image_count']);
    
    update_post_meta($post_id, 'image_count', $stz_image_count);  

    $post_images = $_POST['post_images'];

    if( !empty( $post_images )){
        foreach ($post_images as $post_image) {
            $stz_post_image[] = esc_url_raw($post_image);
        }
    }

    update_post_meta($post_id, 'post_images', $stz_post_image);

}
add_action('save_post', 'parallaxsome_save_post_image');

 /** Making Plugin Translation Ready **/
function load_text_domain() {
    load_plugin_textdomain('parallaxsome-custom-post-type', false, basename(dirname(__FILE__)) . '/languages');
}

add_action('init', 'load_text_domain');